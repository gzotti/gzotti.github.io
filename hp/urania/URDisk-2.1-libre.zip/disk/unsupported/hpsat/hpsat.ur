%%HP: T(3)A(D)F(.);
@ HPSAT was by Albert P. Gerheim, 30.7.1994
@ HPSAT.UR  derived work for Urania/48 V2.0 by G. Zotti
@ Modified: Source formatted & annotated, main progs renamed, ...
@           Prepared for possible library
@           GX only!
@           works for HP's clock in any time zone, not only UT
@           using now Long, Lat, Alt, Zone from Urania
@           UPP: grob used only right half of display. Killed left blank side!!
@ 1.5.1998: Looked at it for the first time
@ 2.-3.5.1998: work...
@ 4.-5.5.1998: minor enhancements. Tested with MIR website -> OK!
@ Version 5.5.1998 first "clean" version
@  4.1.2000: fixed for Urania V2.1 for HP48 and HP49
@            DATA.SAT: default epoch is current year 
@ TODO check TLE file on year format after 2000

DIR
@ library variables. You might kill them!
@ <-LIB-> (for HP48) needs $VARS and $VISIBLE (others are hidden)
@ CRLIB (HP49 built-in command) needs $VISIBLE and $HIDDEN (others are variables)

$ROMID 1597
$TITLE "HPSat for Urania V2.1, AG1994, GZ1998,2000"
$CONFIG \<< 1597 ATTACH \>> @ or just 1. on the HP49
$VARS { PPAR SAT.DAT \Gep\Gw\Gm.$\Ga\Gt PASSES.SAT CST Times.SAT} @ ROOT needs global '\Gep\Gw\Gm.$\Ga\Gt'
$VISIBLE { MAP.SAT EPHEM.SAT PRINT.SAT NEWPASS.SAT DATA.SAT  ABOUT.SAT }
$HIDDEN { TRAK STN SEE HC SC UPP.SUB   }

@ Satellite orbital data:

SAT.DAT @ new in HPSAT.UR, replaces free named vars!
@ format: list of lists, each is:
@ { "Name" [ EpochYearSince1900 EpochDayWithFraction Inclination_deg
@            RAAscNode_deg Eccentricity
@            ArgPerigee_deg MeanAnomalyEpoch_deg MeanMotion_rev/day
@            FirstDerivativeOfMeanMotion_rev/day^2 ] }
@ very easily entered from AMSAT format!
@ use DATA.SAT to edit!

{
{ "MIR"    [   98      121.45216384 51.6584     283.1644 .0004643
              298.8491  61.2034     15.63896494    .00006487        ] }
{ "HUBBLE" [   98      106.01772648 28.4677     264.9256 0.0014373
              101.9101 258.3099     14.86697455   1.490E-05         ] }
}  @  end_SAT.DAT


MAP.SAT
@ was: RT1S.SAT --- MAIN PROGRAM
@ changed: IF 2: DATE 1: TIME: Draw once for that time.
@          ELSE DRAW continuously for current time
@ uses: SAT.DAT
@ changes: cont, ostk, <-bird, <-stim, <-tim, <-q, <-x

\<< 
@ debug:
@ { } DUP DUP 'TIM.DBG' STO 'Q.DBG' STO 'X.DBG' STO
    CLLCD
    IF DEPTH 2 <
    THEN DATE TIME 1    @ 1 is for continuous drawing!
    ELSE           0
    END
    RCLF DEPTH \->LIST DUP
    STD RECT
    "SELECT SATELLITE"
    SAT.DAT
    -1
    CHOOSE.T
    IF NOT THEN DROP OBJ\-> DROP2 DROP KILL END @ drop listSize, flags, cont
                        ""      0    [ 0 0 0 ] 0    { }
    \-> ostk \<-bird \<-stim \<-tim  \<-q      cont \<-x
    \<< OBJ\-> DROP2    @ restore stack w/o flags
        'cont' STO      @ above: result of DEPTH 2 \<=
        IFERR           @ trap [ON]-presses
         1              @ for first AND below...
         WHILE KEY NOT AND @ work until any key has been pressed
         REPEAT DUP2 TSTR  '\<-stim' STO
                ZT\|>JD 1.011990 0 UT\|>JD - '\<-tim' STO
@ debug:
@  \<-tim 'TIM.DBG' STO+

                TRAK @ call TRAK

                STN  @ call STN
@ debug:
@  \<-x 'X.DBG' STO+
@  \<-q 'Q.DBG' STO+

                SEE  

                DATE TIME cont @ feed for AND in WHILE condition above
         END    @ this ends either because cont=0 or pressed key.
         IF cont
         THEN DROP               @ key code
         ELSE { } PVIEW          @ rest only for one-shot run
         END
         DROP2                   @ date, time
        THEN        @ ERROR ([ON] pressed...)
        END
        '\Gep\Gw\Gm.$\Ga\Gt' PURGE
        CLEAR ostk OBJ\-> DROP STOF DROP DROP2
    \>>
\>>


EPHEM.SAT
@ was: FTMS --- multiple passes finder.
@ Settings: Print to IR and/or PASS.SAT; draw MAP?
@ Enter Start/End date/time and increment.
@ For each  sat in SAT.DAT: find pos and print/add line if visible.
@ program takes very long!
@ TODO: SysRPL INFORM with check marks for output selection instead of HALT
\<< RCLF DEPTH \->LIST
            0     1 0     0  [ 0  0  0 ] { }  0      ""      { }     0    
   \-> ostk mhc msc msee  go \<-q        \<-x \<-tim \<-stim \<-bird add  
   \<<
    IFERR 
     DO 
        mhc
             { { "PRIN\[]"  \<< 0 'mhc' STO CONT \>> } }
             { { "PRINT"    \<< 1 'mhc' STO CONT \>> } }
        IFTE
        msc
             { { "PASS\[]"  \<< 0 'msc' STO CONT \>> } }
             { { "PASS"     \<< 1 'msc' STO CONT \>> } }
        IFTE
        msee
             { { "MAP\[]"   \<< 0 'msee' STO CONT \>> } }
             { { "MAP"      \<< 1 'msee' STO CONT \>> } }
        IFTE
             { } { }  { "GO!"   \<< 1 'go' STO CONT \>> }
        6 \->LIST TMENU HALT 0 MENU
     UNTIL go
     END
     IF msc
     THEN IF PASS.SAT TYPE 2 \=/        @ create PASS.SAT if nonexistent!
          THEN "" 'PASS.SAT' STO
          END
     END
@ gzotti replaced INPUT with INFORM.
     "ENTER TIMES"
     { { "D1:" "Start Date" 0 }
       { "T1:" "Start Time" 0 }
       { "D2:" "End Date" 0 }
       { "T2:" "End Time" 0 }
       { "INCR:" "Interval betw. passes (HH.MMSS)" 0 } }
     { 2 0 }

     DATE TIME DUP2 ZT\|>JD 24 INV + JD\|>ZT 0.0230 5 \->LIST @ default as reset
     IF Times.SAT TYPE 5 \=/    @ not a list?
     THEN DUP 'Times.SAT' STO
     END
@ { startDate_48 startTime_HMS endDate_48 endTime_HMS increment_HMS }
     Times.SAT
     INFORM
     IF NOT THEN 0 DOERR END       @ user pressed [ON]/CANCL
     CLLCD
     DUP 'Times.SAT' STO
     OBJ\-> DROP HMS\-> 24 / 'add' STO
@ Now valid time in TIMES.SAT and on stack. increment in local 'add'
         ZT\|>JD ROT ROT ZT\|>JD SWAP

         FOR jd jd 1.011990 0 UT\|>JD -  '\<-tim' STO
               jd JD\|>ZT TSTR
                               IF msee NOT THEN DUP CLLCD 4 DISP END
                               '\<-stim' STO
@ Sky contained interesting satellites. we take all!
@ TODO: SysRPL CHOOSE with checkmarks to select interesting satellites
@ usually there are only MIR, HUBBLE, SHUTTLE, so not much to do,
@ so for now we take all!
@              Sky OBJ\->
@               DUP 1 SWAP START CLEAR Sky OBJ\-> ROLL DUP 'BIRD' STO
@                                      DEPTH \->LIST 'Sky' STO
@                                      TRAK STN

               SAT.DAT
               1 OVER SIZE FOR sat
                               DUP sat GET '\<-bird' STO
                               TRAK STN       @ do the hard work...
                               STD
                               IF msc THEN SC END     @ output result
                               IF mhc THEN HC END
                               IF msee THEN SEE END
                           NEXT
               DROP
         add STEP                                     @ next time run
   THEN  @ IFERR... ( i.e. user pressed [ON] ) 
   END
   CLEAR
   ostk OBJ\-> DROP STOF
  \>> '\Gep\Gw\Gm.$\Ga\Gt' PURGE
\>>

PRINT.SAT @ replaces CST entry "DUMP"
\<< 1.5 DELAY 'PASS.SAT' PRVAR \>>

NEWPASS.SAT @ replaces CST entry "CLR"
\<< "" 'PASS.SAT' STO \>>


DATA.SAT @  New program to simplify editing of orbital data of Satellites.
@ It allows adding, changing and deleting orbital data.
@ (derived from DATA.GX of Urania/48 V2.0)

\<<
CLLCD
{ { "NAME"  "less than 8 chars, please!"    2 }
  { }
  { }
  { "YR"    "Year since 1900"               0 }
  { "EP"    "Epoch (days with fraction)"    0 }
  { "i"     "Inclination, deg"              0 }
  { "\GW"   "Right Asc. of Asc.Node, deg"   0 }
  { "e"     "Eccentricity of orbit"         0 }
  { "\Gw"   "Arg. of Perigee, deg"          0 }
  { "M"     "Mean Anomaly/Epoch, deg"       0 }
  { "n."    "Mean Motion, rev/day"          0 }
  { "n.'"   "1st deriv. of n., rev/day^2"   0 }
}

 \-> shlp
 \<<
 "YOU HAVE A SATELLITE TO"

 { { "add"
    \<< "ADD SATELLITE"
        shlp
        { 3 0 }
        { NOVAL 98 NOVAL NOVAL NOVAL NOVAL NOVAL NOVAL  14 0 }
	2 DATE SPLITDATE 3 ROLLD DROP2 1900 - PUT @ put current year into list 
        DUP
        INFORM
        IF NOT THEN 0 DOERR END
        OBJ\-> DROP 9 \->ARRY 2 \->LIST
        1 \->LIST
        SAT.DAT SWAP + SORT
        'SAT.DAT' STO
    \>> }

   { "edit"
      \<< "EDIT SATELLITE"
          SAT.DAT 1 CHOOSE.T
          IF NOT THEN 0 DOERR END
          SAT.DAT OVER POS                @  {data.nr} nr
          \-> lst nr
          \<< "EDIT SATELLITE"
              shlp
              { 3 0 }
              lst
              OBJ\-> DROP OBJ\-> DROP 10 \->LIST
              DUP
              INFORM
              IF NOT THEN 0 DOERR END
              OBJ\-> DROP 9 \->ARRY 2 \->LIST
              SAT.DAT nr ROT PUT 'SAT.DAT' STO
          \>>
      \>> }

    { "delete"
      \<< "DELETE SATELLITE"
           SAT.DAT 1 CHOOSE.T
           IF NOT THEN 0 DOERR END
           SAT.DAT DUP ROT POS          @ {1..n} #
           OVER 1 3 PICK 1 - SUB        @ {1..n} # {1..#-1}
           ROT ROT 1 + OVER SIZE SUB +  @ {1..#-1,#+1..n}
           'SAT.DAT' STO
      \>> } }
 1 CHOOSE
 IF THEN EVAL END
 \>> @ shlp off

\>>


ABOUT.SAT
\<<
IFERR
-40 FS?C                              @ Clock off
CLLCD                                 @ Blank the menu while waiting for
{ } TMENU                             @ keypresses between screens.
"HP Satellite Tracker

Based on HPsat, the
HP 48SX implementation
 of the SGP model
 by Albert P. Gerheim
gerheim@sonalysts.com"  1 DISP
-1 WAIT DROP
 CLLCD

"   This Version is
   for Urania V2.1
and HP48G(X) or HP49G
     series only

   by Georg Zotti
 05/1998 and 01/2000"          1 DISP
-1 WAIT
THEN END                              @ IFERR..i.e. ON pressed
DROP
0 MENU
IF THEN -40 SF END                    @ Clock?
\>>


TRAK
@ hard work calculating position above ground (?)
@ uses <-bird, global: \Gep\Gw\Gm.$\Ga\Gt(ROOT needs that!), <-tim
@ changes <-q
@ V2.1 changed all EVAL to \->NUM

\<< \<-bird OBJ\-> ROT DROP2 V\->
 \-> yr0 day0 i raan ecc om m0 n ndot
 \<< 1.011990 yr0 1000000 / 1.0119 + DDAYS day0 1 - + 0 0 0
  \-> t0 r0 r1 r2
  \<< '(n+2*ndot*(\<-tim-t0))^(4/3)*1.33288144164E-2*n*(\<-tim-t0)/SQ(1-SQ(ecc))'
      \->NUM 'r0' STO
      'raan' 'r0*COS(i)' \->NUM STO-
      'om'   'r0*(2-2.5*SQ(SIN(i)))' \->NUM STO+
      'ecc*COS(om)' \->NUM
      '.00002641023*n^(2/3)*SIN(i)/(1-SQ(ecc))' \->NUM DUP
      \-> ax ay u
       \<< 'u'  'ax*(3+5*COS(i))/(2*(1+COS(i)))' \->NUM STO*
           'ay' 'ecc*SIN(om)' \->NUM STO+
           \<-tim t0 - 'r0' STO
           'u' 'D\->R((360*(SQ(r0)*ndot+n*r0)+om+m0) MOD 360)' \->NUM STO+
           'ay*COS(R\->D(\Gep\Gw\Gm.$\Ga\Gt))-ax*SIN(R\->D(\Gep\Gw\Gm.$\Ga\Gt))+\Gep\Gw\Gm.$\Ga\Gt-u'
           '\Gep\Gw\Gm.$\Ga\Gt' u ROOT R\->D '\Gep\Gw\Gm.$\Ga\Gt' STO
           'ax*COS(\Gep\Gw\Gm.$\Ga\Gt)+ay*SIN(\Gep\Gw\Gm.$\Ga\Gt)' \->NUM
           '-ay*COS(\Gep\Gw\Gm.$\Ga\Gt)+ax*SIN(\Gep\Gw\Gm.$\Ga\Gt)' \->NUM
           '(7.53712273449E13/SQ(n+2*ndot*(\<-tim-t0)))^(1/3)' \->NUM
           'SQ(ax)+SQ(ay)' \->NUM

           \-> ecos esin a el2
            \<< 'a*(1-el2)' \->NUM 'a*(1-ecos)' \->NUM
             \-> pl r
              \<< 'esin/(\v/(1-el2)+1)' \->NUM 'r2' STO
                  'COS(\Gep\Gw\Gm.$\Ga\Gt)-ax+ay*r2'  \->NUM 'r0' STO
                  'SIN(\Gep\Gw\Gm.$\Ga\Gt)-ay-ax*r2'  \->NUM 'r1' STO
                  r1 r0 ATN2 'r1' STO
                  r
                  'r1+SIN(2*r1)*(7*SQ(COS(i))-1)*315721.018307/SQ(pl)' \->NUM
                  P\->R i P\->R 'r2' STO
                  R\->P raan + P\->R
                  RECT r2 \->V3 '\<-q' STO
              \>>
            \>>
       \>>
  \>>
 \>>  @ '\Gep\Gw\Gm.$\Ga\Gt' PURGE
\>>



STN
@ calculates from geocentric position (TRAK)? and obs. coords. sat.pos. for obs
@ uses \<-q, Long, Lat, Alt
@ changes \<-x
\<<
    Lat Long Alt 1000 /
    3 PICK COS SQ
    4 PICK SIN SQ
    .99330561499
    \-> lat lon h  r0 r1 r2
    \<<
       '6378.15*((r0+r1*SQ(r2))/(r0+r1*r2))^.5' \->NUM
       'ATAN(r2*TAN(lat))' \->NUM
       'lon+100.225+\<-tim*360.985647647 MOD 360' \->NUM
       \-> rho latp lonp
        \<< 'rho' 'h/ACOS(latp-lat)' \->NUM STO+
            \<-q
            SPHERE rho lonp 90 latp - \->V3
            RECT - V\-> 'r2' STO
            R\->P lonp -
            P\->R r2 SWAP 'r2' STO
            R\->P lat -
            P\->R r2 SWAP ROT
            \->V3 SPHERE V\-> 90 SWAP -
            SWAP 90 SWAP - 360 MOD SWAP 3 \->LIST '\<-x' STO
        \>>
    \>>
\>> @ end STN



SEE @ show sky chart (w/ sat, but w/o stars...) and Az/Alt data
@ used by: RT1S
@ uses:     <-stim, <-x, <-bird
@ changes:  ---
\<< { # 0d }
    # 131d # 64d BLANK { # 63d # 1d } UPP.SUB REPL
    @ 0 FIX !!???

    OVER # 0d + \<-stim 1 \->GROB REPL             @ {#0} UPP_w/time

     \<-x OBJ\-> DROP                              @ {#0} UPP' dist az alt

     0 RND "Alt = " SWAP + "\^o" + 1 \->GROB
     4 ROLL 5 PICK # 30d + ROT REPL                @ {#0}  dist az UPP"

     "Az  = " ROT 0 RND + "\^o" + 1 \->GROB        @ {#0}  dist UPP" grob
     4 PICK # 20d + SWAP REPL                      @ {#0} dist UPP"'

     "Dist= " ROT 0 RND + " km" + 1 \->GROB        @ {#0} UPP"' grob
            3 PICK # 10d + SWAP REPL               @ {#0} UPP""

     OVER   # 40d + \<-bird HEAD 2 \->GROB REPL    @ {#0} UPP""'
     OVER   # 49d + \<-x 3 GET 0 > "" "not " IFTE
                          "visible at" + 1 \->GROB REPL  @ {#0} UPP"""
     OVER   # 56d +
      Long 1 RND DUP ABS SWAP 0 > "\^oE/" "\^oW/" IFTE +
      Lat  1 RND DUP ABS SWAP 0 > "\^oN" "\^oS" IFTE + +
      2 \->GROB REPL
     SWAP # 0d +                   @ UPP''''' {#0 #0}
     PICT OVER 4 ROLL REPL         @ {#0 #0}
     PVIEW
     \<-x
     IF DUP 3 GET 0 >              @ draw satellite if above horizon
     THEN
           OBJ\-> DROP     @ dist az alt
           90 SWAP - SWAP 90 + @ dist 90-alt az+90
           -279 93 XRNG
            -90 93 YRNG
           P\->R R\->C C\->PX
           { # 1d # 1d } - PICT SWAP GROB 3 3 205020 REPL
           DROP @ drop range (left from <-x)
     ELSE DROP @ drop <-x
     END
\>>



HC @ prints output to IR printer
@ used by: FTMS
@ uses: \<-bird, \<-x, \<-stim, Long, Lat
@ changes: ---
    \<< \<-x OBJ\-> DROP
      IF DUP 0 >
      THEN \<-bird HEAD " at " + @ no station names in U/48, so...
           Long 1 RND DUP ABS SWAP 0 > "\^oE/" "\^oW/" IFTE +  @ coords.
           Lat  1 RND DUP ABS SWAP 0 > "\^oN" "\^oS" IFTE + + +
           PR1 DROP                             @ stack: dist az alt
           1 RND SWAP 1 RND ROT 0 RND           @ alt az dist

           "Az= " ROT + "\^o, Alt= " + ROT + "\^o" + PR1 DROP
           "Dist= " SWAP + " km" + PR1 DROP
           \<-stim PR1 DROP
           CR                   @ add linefeed...
      ELSE DROP DROP2
      END
\>>

SC @ processes output and stores it into PASS.SAT
@ used by: FTMS
@ uses: \<-bird, \<-x, \<-stim, Long, Lat
@ changes: PASS.SAT
\<< \<-x OBJ\-> DROP                                    @ dist az alt
    IF DUP 0 >
    THEN \<-bird HEAD  " at " +
         Long 1 RND DUP ABS SWAP 0 > "\^oE/" "\^oW/" IFTE +
         Lat  1 RND DUP ABS SWAP 0 > "\^oN" "\^oS" IFTE + + + @ dist az alt ""
         "\010Az= " + ROT 1 RND "\^o, Alt= " + +              @ dist alt ".."
         SWAP 1 RND "\^o\010Dist= " + +
         SWAP 0 RND " km\010" + +
         \<-stim "\010\010" + + 'PASS.SAT' STO+
    ELSE DROP DROP2
    END
\>>


UPP.SUB
GROB 67 63 0000000CFF10000000000000C342E100000000000830C20E00000000000600C300300000000081004300C000000000400042000100000000200000000200000008100000000C00000004000000000010000002000000000020000001000000000040000080000000000080000080000000000080000040000000000001000020000000000002000010000000000004000010000000000004000800000000000008000800000000000008000400000000000000100400000000000000100400000000000000100200000000000000200200000000000000200200000000000000200200000000000000200100000000000000400100000000000000400100000000000000407100000000000000401100000041000000407100000080000000401100000041000000407100000000000000400100000000000000400100000000000000400100000000000000400200000000000000200200000000000000200200000000000000200200000000000000200400000000000000100400000000000000100400000000000000100800000000000008000800000000000008000010000000000004000010000000000004000020000000000002000040000000000001000080000000000080000080000000000080000001000000000040000002000000000020000004000000000010000008100000000C0000000020000000020000000040000000010000000081000000C0000000000600000030000000000830000E000000000000C300E10000000000000CFF10000000


CST { MAP.SAT EPHEM.SAT PRINT.SAT NEWPASS.SAT DATA.SAT  ABOUT.SAT }

END @ directory SAT

