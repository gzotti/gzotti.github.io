%%HP: T(3)A(R)F(.);
@ GEOSTAT.UR for Urania V2.1 with UTools(+) by Georg ZOTTI
@ Finder for geostationary satellites, based on a 1995(?) Compuserve posting.
@
@ uses: Long, Lat: Urania-wide  Coordinates of the observer
@       AaH\Gd: Coordinate Transformation Az/Alt->HourAngle/Dec
@       \->HMd: decimal Degrees-> Degrees w/min and decimals
@       CHOOSE.T: AstroTools: enhanced CHOOSE
@ 22.4.1998   Bytes: 488.5 (program alone)
@ 16.7.1998   (start was buggy)
@  4.1.2000   fixed for V2.1: renamed CHOOS2 to CHOOSE.T
@ TODO: get recent satellite data! (Those here are from ~1994!?)
\<<
"Select Satellite"
{ { "Satcom I"    -135   }
  { "Satcom II"   -119   }
  { "Satcom IIIR" -131   }
  { "Westar II"   -123.5 }
  { "SBS"         -106   }
  { "TDRS West"   -171   }
  { "TDRS East"    -41   } }
1 CHOOSE.T
IF NOT THEN KILL END                @ { "Name" lambda }
EVAL Long SWAP -                    @ "Name" (Lambda-lambda)
DUP COS Lat COS * DUP ACOS          @ "Name" (Lambda-lambda) cos(theta) theta
SWAP 0.15113 - OVER SIN / ATAN      @ "Name" (Lambda-lambda) theta E
Lat TAN NEG ROT TAN / ACOS          @ "Name" (Lambda-lambda) E A'
IF ROT SIN 0 > THEN NEG 360 + END   @ "Name" E A
SWAP DUP2 AaH\Gd                    @ "Name" A=Az E=Alt H dec

@ Now we add a little output stuff:
HMS\-> \->HMd SWAP HMS\-> \->HMd
4 \->LIST { 1 1 2 2 } RND           @ "Name" { Az.d Alt.d dec.MM H.MM }
SWAP ": Az" +
{ "Alt" "\Gd" "HA" } + \->TAG EVAL SWAP

\>>

