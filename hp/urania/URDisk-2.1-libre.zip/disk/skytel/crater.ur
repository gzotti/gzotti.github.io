%%HP: T(3)A(D)F(.);

@ CRATER  by G. Zotti, Vienna, <e9126124 (at) student.tuwien.ac.at>

@ Calculates impact crater dimensions
@ Based on the program CRATER.BAS by John Kennewell,
@ found in Sky&Telescope 11/1996, p.92

@ USES: Urania V2.1: UTools(+) ( PAD$, REAL$ )

@  1: (---)     ->   DataPICT

@ This is a BASIC-transscript, so it is rather unreadable to non-S&T-readers.
@ I avoided to use local variables and implemented most parts in pure RPL/RPN,
@ so read the comments!

@ PICT is used as output.
@ Calculator mode is restored at program's end.

@ Version 2, 13.11.1996          Checksum: # 6011h       Bytes: 1381 (w/o name)

\<< RCLF
"Terrestrial Impact Crater"
{ { "Diameter:"  "Impactor diameter (m)"            0 }
  { "Density:"   "Impactor density (kg/m^3)"        0 }
  { "Speed:"     "Impactor Velocity (km/s)"         0 }
  { "Angle:"     "Graze Angle (Deg fr. Horizontal)" 0 }
}
{ 1 4 }
{ 300 2700 26 60 }
DUP
INFORM
IF NOT THEN DROP 0 DOERR END
DEG
EVAL   SIN .33 ^                         @ id ir ik gf
4 ROLL 3 ^ \pi * 6 / \->NUM              @ ir ik gf vi
4 ROLL OVER *                            @ ik gf vi mi
4 ROLL 1000 * SQ OVER 2 / * DUP 4.2E12 / @ gf_ vi mi ke kt_
CLLCD @ kill ADISP with INFORM-mask
PICT PURGE

{ # 0d # 0d } PVIEW
PICT { # 25d #  1d } "IMPACTOR PARAMETERS" 1 \->GROB REPL
2 ENG
PICT { #  1d #  8d } "VOL: " 7 ROLL \->STR +
                    "m^3  MASS: " + 6 ROLL \->STR + "kg" + 1 \->GROB REPL
PICT { #  1d # 14d } "KIN.ENRG: " 5 ROLL 0 RND -5 RND  \->STR +
                     "J ~" + 4 PICK \->STR "kT TNT" + + 1 \->GROB REPL

.3 ^ *                                  @ gf*kt^(1/3)
DUP 36 * DUP 1.25 *                     @ gf*kt^(1/3) cd ca
ROT  9 * DUP 1.25 *                     @ cd ca cz cl
OVER 5 PICK SQ * 0.125 * \pi * \->NUM   @ cd ca cz cl cv
5 PICK 2.15 *                           @ cd ca cz cl cv ce

SWAP                                    @ cd ca cz cl ce cv

STD
PICT { # 28d # 21d } "CRATER PARAMETERS" 1 \->GROB REPL
[ 28 34 40 46 52 58 ]                   @ y-positions
{ "DIAMETER, ACTUAL:" "DIAMETER, APPARENT:" "DEPTH, ACTUAL:"
  "DEPTH, APPARENT:"  "EJECTA SPREAD:"      "VOLUME REMOVED:"
}
1 6 FOR x OVER x GET R\->B { # 1d } SWAP + OVER x GET 1 \->GROB
          PICT ROT ROT REPL
    NEXT
DROP @ $List
@ #flags [yPos]
STD
1 6 FOR x PICT OVER x GET R\->B { # 75d } SWAP +
@          IF x 6 == THEN 2 ENG { 2 0 } ADD END | activate this line for HP48
          IF x 6 == THEN 2 ENG END
          10 x - ROLL 0 RND \->STR 
          IF x 6 \=/ THEN 1 OVER SIZE 1 - SUB END
          9 PAD$ x 6 < " m" " m^3" IFTE  + 1 \->GROB REPL
    NEXT
DROP @ [yList]
STOF
{ } PVIEW
\>>









