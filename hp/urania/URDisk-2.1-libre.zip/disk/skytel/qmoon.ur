%%HP: T(3)A(D)F(.);

@ QMOON, by G. Zotti, Vienna, <e9126124(at)student.tuwien.ac.at>

@ Based on program MOON EFFECTS by Bradley E. Schaefer,
@ found in Sky&Telescope 4/1994, p.88

@ Precision: Sufficient for rough estimates �5000 years from now
@ Schaefer: " [...] The program does not treat fractions of a day, and it also
@            omits the many periodic terms in the Moon's complex motion. The
@            age, distance and latitude are accurate to whole units in each
@            case. The longitude is only a rough guide because it increases
@            about 13� per day. Yet these values are good enough for most
@            historical questions. [...] "

@ USES: Urania/48 V2.[01]: UT|>JD
@   or: uncomment commented part below, then it's standalone!

@ Usage: 1: Date  ->  4:        Age: XX.x_d      | Age (days) from New Moon
@                     3: Dist(56~64): XX_Rd      | Distance (Earth Radii)
@                     2:    Ecl.Lat: �X.x_�      | Ecl. Latitude  (Degrees)
@                     1:    Ecl.Long: XXX_�      | Ecl. Longitude (Degrees)

@ Input Date format is the current HP48 date format,
@ depending on state of system flag -42

@ The values are computed for 12.00 UT of the day in question


\<<
  IF DEPTH NOT THEN DATE END                    @ default: today
  RCLF SWAP RAD                                 @ save Flags, set Radians-mode
@  DUP  IP    ABS                                | split date
@  SWAP FP 100   *
@  DUP  FP 10000 *
@  SWAP IP ABS ROT
@  IF -42 FC? THEN SWAP END                      | which date format?
@  \-> y m d

@  \<< y 12 m - 10 / IP - 'y' STO                | calculate Julian date
@      m 9 + 12 MOD       'm' STO
@      365.25 y 4712 + * IP                      | K1
@      30.6 m * .5 + IP                          | K2
@      + d + 59 +
@      IF DUP 2299160 >
@         THEN y 100 / 49 + IP .75 * IP 38 - -   | K3 used only in Gregorian
@         END                                    | calendar
@  \>>


@ Use other programs - get the same:

0 UT\|>JD .5 +


  @ J is Julian date at 12 UT on day in question
  'two\pi' CONST UVAL                           @ P2
  \-> J \pi2

  \<< @ Calculate illumination (synodic) phase
      J 2451550.1 - 29.530588853 / 1 MOD        @ IP (Ip in this program!)
      DUP '29.53_d' * 1 RND "Age" \->TAG        @ AG, Moon's age in days
      SWAP \pi2 *                               @ Convert phase to radians

      @ Calculate distance from anomalistic phase
      J 2451562.2 - 27.55454988  / 1 MOD \pi2 *            @ DP
      \-> Ip DP
      \<< 60.4 3.3 DP COS * -                              @ DI
            .6 2 Ip * DP - COS * -
            .5 2 Ip * COS * -
            '1_Rd' * 0 RND "Dist(56~64)" \->TAG

            @ Calculate latitude from nodal (draconic) phase
            J 2451565.2 - 27.212220817 / 1 MOD \pi2 *      @ NP
            SIN '5.1_\^o' * 1 RND "Ecl.Lat." \->TAG        @ LA

            @ Calculate longitude from sidereal motion
            J 2451555.8 - 27.321582241 / 1 MOD             @ RP
            360 *  6.3 DP   SIN * +
            1.3 2 Ip * DP - SIN * +
             .7 2 Ip * SIN * + '1_\^o' *
            0 RND "Ecl.Long." \->TAG                       @ LO
            5 ROLL STOF
      \>>
   \>>
\>>


