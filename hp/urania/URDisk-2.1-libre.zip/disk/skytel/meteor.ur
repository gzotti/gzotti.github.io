%%HP: T(3)A(R)F(.);
@ METEOR for Urania V2.1 with UTools by Georg ZOTTI
@ For any given year, this program lists the major meteor showers and
@ the UT dates of maximum activity.  From Sky & Telescope, Aug '89, p. 195.

@ METEOR:

@  ( Year ) -> PICT filled with data

@ 28.9.1996 Georg ZOTTI for Urania/48 V2.00
@ 06.1.2000 adapted for Urania 2.1 and HP49.

\<< PICT PURGE                          @ 10 REM      METEOR SHOWERS
                                        @ 12 R1=3.1415927/180: DIM M$(12)
                                        @ 14 DIM N$(9),S0(9),S1(9),J5(9)
                                        @ 16 FOR I=1 TO 12: READ M$(I): NEXT
                                        @ 18 DATA JAN,FEB,MAR,APR,MAY,JUN
                                        @ 20 DATA JUL,AUG,SEP,OCT,NOV,DEC
IF DEPTH NOT                            @ 22 FOR I=1 TO 9
THEN DATE 100 * FP 10000 *              @ 24 READ N$(I),S0(I),S1(I),J5(I)
END                                     @ 26 NEXT I

RCLF SWAP STD DEG
PICT { # 0d # 0d } DUP PVIEW
"Meteor Showers " 4 PICK 0 REAL$ + 2 \->GROB REPL
PICT { # 117d # 2d } "(UT)" 1 \->GROB REPL

1950 - 100 /                            @ 28 INPUT "YEAR";Y: T5=(Y-1950)/100
# 9d
IF OVER ABS 1.5 \>= THEN 2 * END

             0  0  0
\-> t5 ypos s0 s1 j5
\<<
1 9 FOR i                               @ 30 FOR I=1 TO 9
    IF t5 ABS 1.5 <                     @ 32 IF ABS(T5)<1.5 THEN 36
       { 1 4 9 } i POS NOT OR           @ 34 IF I=1 OR I=4 OR I=9 THEN 70
    THEN { { "Quadrantids"      282.9  -0.4   285.3 }
           { "Lyrids"            31.7   0.06  393.9 }
           { "Eta   Aquarids"    44.0   0.3   406.6 }
           { "Delta Aquarids"   125.0  -1.0   491.2 }
           { "Perseids"         139.2   0.03  506.0 }
           { "Orionids"         207.7   0.4   576.2 }
           { "Taurids"          220.0   0.44  588.5 }
           { "Leonids"          234.3   1.5   602.7 }
           { "Geminids"         261.4   0     629.5 } }
           i GET EVAL 'j5' STO 's1' STO 's0' STO
         PICT # 8d ypos 2 \->LIST ROT 1 \->GROB REPL

         s1 t5 * s0 +                   @ 36 S=S0(I)+S1(I)*T5
         t5 .0003 * 1.39663 + t5 * +    @ 38 S=S+1.39663*T5+.0003*T5*T5
         360 MOD                        @ 40 S=S-360*INT(S/360)
         36525.636 s1 + t5 * j5 +       @ 42 J=J5(I)+36525.636*T5+S1(I)*T5
         @ S J
         1 2 START                      @ 44 FOR K=1 TO 2
            DUP 2433000 + JD\->T        @ 46 T=(J+2433000-2415020)/36525
            DUP -0.0003032 *            @ 48 L=279.7+36000.769*T+.0003*T*T
             35999.0503 + OVER *        @ 50 M=358.48+35999.05*T-.0002*T*T
             357.5291 +                 @ 52 S5=L+(1.92-.005*T)*SIN(M*R1)
            SWAP 0 SunPos DROP2         @ 54 S5=S5+.02*SIN(2*M*R1)
                                        @ 56 S5=S5-360*INT(S5/360)
            @ S J M S5
            4 PICK - SWAP COS .033 *    @ 58 J=J-(S5-S)/(.986+.033*COS(M*R1))
            .986 + / -          @ S J
         NEXT                           @ 60 NEXT K
         SWAP DROP 2433000 +            @ 62 F=J-INT(J): J=INT(J)+2433000
         JD\|>UT HMS\-> 0 RND           @ 64 GOSUB 96
         IF DUP 24 ==                   @ 66 PRINT N$(I);TAB(15);M$(M);
         THEN DROP 1 Date+ 0            @ 68 PRINT USING "###.#";D
         END
         SWAP SPLITDATE DAT$ SWAP 0 REAL$ 3 PAD$ +
         PICT # 76d ypos 2 \->LIST ROT 1 \->GROB REPL
         # 6d 'ypos' STO+
    END
NEXT                                    @ 70 NEXT I
                                        @ 72 END
                                        @ 74 REM  SHOWER DATA
                                        @ 76 DATA "QU'DNTDS",282.9,-0.4,285.3
                                        @ 78 DATA "LYRIDS  ",31.7,0.06,393.9
                                        @ 80 DATA "ETA AQR ",44.0,0.3,406.6
                                        @ 82 DATA "DLT AQR ",125.0,-1.0,491.2
                                        @ 84 DATA "PERSEIDS",139.2,0.03,506.0
                                        @ 86 DATA "ORIONIDS",207.7,0.4,576.2
                                        @ 88 DATA "TAURIDS ",220.0,0.44,588.5
                                        @ 90 DATA "LEONIDS ",234.3,1.5,602.7
                                        @ 92 DATA "GEMINIDS",261.4,0,629.5
                                        @ 94 REM
                                        @ 96 REM   JD --> CALENDAR
                                        @ 98 G=1: IF J<2299161 THEN G=0
                                        @ 100 F=F+.5: IF F<1 THEN 104
                                        @ 102 F=F-1: J=J+1
                                        @ 104 IF G=1 THEN 108
                                        @ 106 A=J: GOTO 112
                                        @ 108 A1=INT((J/36524.25)-51.12264)
                                        @ 110 A=J+1+A1-INT(A1/4)
                                        @ 112 B=A+1524
                                        @ 114 C=INT((B/365.25)-.3343)
                                        @ 116 D=INT(365.25*C)
                                        @ 118 E=INT((B-D)/30.61)
                                        @ 120 D=B-D-INT(30.61*E)+F
                                        @ 122 M=E-1: Y=C-4716
                                        @ 124 IF E>13.5 THEN M=M-12
\>>                                     @ 126 IF M<2.5 THEN Y=Y+1
STOF
{ } PVIEW
\>>                                     @ 128 RETURN

