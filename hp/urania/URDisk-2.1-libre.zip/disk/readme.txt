A short overview of the programs included with the Urania package V2.1:

Many files have names that include version number and/or
calculator model.

These are the libraries in the registered version

AARes.lib      - Lib ID 1610 - Resource library for all programs
Urania.lib     - Lib ID 1609 - Main command library
Moon.lib       - Lib ID 1608 - Moon extension
SomeTools.lib  - Lib ID 1607 - UTools (-) Basic tools
AstroTools.lib - Lib ID 1607 - UTools (+) Complete Astronomical Toolbox
SaMoon.lib     - Lib ID 1606 - Saturn's Moons 
RNGC1.lib      - Lib ID 1602 - RNGC extension
RNGC2.lib      - Lib ID 1601 - RNGC add-on: Dreyer's NGC descriptions
RNGC3.lib      - Lib ID 1600 - RNGC add-on: New RNGC descriptions

ANA     Shows the analemma 
PHENO   Calculates the most important Planetary Phenomena for a whole year

Now the contents in the Disk package.

SITE.DAT List of observing sites { { "SiteName" [ Long Lat Alt Zone ] } ... }
SITE.GX  Program for selecting/adding/removing observing sites
SITE.SX  Modified version, for HP-48SX

COMET.DAT    Data list for Comets
ASTEROID.DAT Data list for Asteroids (Minor Planets)
DATA.GX  Program for adding/modifying/deleting Comet and Asteroid data
DATA.SX  Modified version, for HP-48SX

QVSOP.zip contains the QVSOP directory with libraries for both calculator
models and source code. QVSOP is under GNU license, see file COPYING.

The DATA directory contains the built-in data from Urania for
reference purposes.

Some more example programs are included. These might or might not be
useful for anyone, and are not "officially" supported:

In the PHASES directory you can find PHASES(4[89]|50).DIR, prepared for library  
creation (ID1605), for drawing planets with their phase images.

The ANIM directory contains a few animations made with an early version
of PHASES. Works on HP48 only, but you could make your own animations 
for the HP49.

In the MORE directory are some more programs (some of them not to be taken
seriously!). These are described in their respective source files. 

The SKYTEL directory contains programs that were adapted from Sky&Telescope 
articles. 

The HPSAT directory contains Albert Gerheim's HPSat satellite tracker program
 (in HPSAT.ZIP) as well as a variant of this program to be used with
 Urania: HPSAT.UR contains the annotated source code, prepared for 
 library creation (ID1597). Unfortunately, the program lacks a way to find
 whether a satellite is sunlit. See the original doc and HPSAT.UR for more
 info. HPSAT is included here by courtesy of Albert Gerheim.
 GEOSTAT.UR, also in that directory, is a finder program for geostationary
 satellites.

