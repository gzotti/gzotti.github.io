%%HP: T(3)A(D)F(.);
@ Fr13 is an example how to use date arithmetic of Urania.
@ This one can be useful to warn superstitious people or others
@ interested in the date "Friday the 13.", but it can be changed easily.

@ 1: YYYY   ->   all Fridays, the 13. of a year. ( Strings )
@                ! Stack levels as needed !!

@ V2.1: changed for new behavior of WDAY


\<<
 IF DEPTH NOT THEN DATE 100 * FP 10000 * END
 \-> y
 \<< 1 12 FOR m 13 m
@             IF -42 FC? THEN SWAP END
@            100 / y 1000000 / + +
             y BINDDATE
             IF WDAY DUP OBJ\-> SWAP DROP  "Friday" \=/
             THEN DROP
             END
          NEXT
  \>>
\>>
