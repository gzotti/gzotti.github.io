%%HP: T(3)A(D)F(.);

@ WIPE demonstrates usage of DRWCIRCLE.

\<< 1 60 FOR i { # 41h # 20h } DUP i 0 DRWCIRCLE        @ black ring
             IF i 5 >
             THEN i 5 - NEG 0 DRWCIRCLE                 @ white ring
             ELSE DROP
             END
         NEXT
\>>
