%%HP: T(3)A(D)F(.);

@ PSPEED calculates a planet's, comet's or asteroid's current mean speed,
@ Perihel speed, Aphel speed and orbital length
@ Objects must have elliptic orbit!
@ Formulae from Jean Meeus, Astronomical Algorithms, chapter 32.
@ USES: Urania V2.1: Urania, UTools(+), ASTEROID.DAT, COMET.DAT

@ V 1.00   15.5.1997 works for elliptical orbits. e:=min(e, 0.99999999)
@ V 1.00.1 29.5.1997 Asteroid bug solved
@ V2.1      5.1.2000 for Urania V2.1

@ TODO:  make IF Comet THEN CASE e=1 ... e>1 ... e<1 ... END
@                      ELSE IF PLANET THEN planet...
@                                     ELSE asteroid


@                                     4: :Name: xxx_km/s
@                                     3: :Vp:   xxx_km/s
@ ( 2: Date )                         2: :Va:   xxx_km/s
@ ( 1: Time )      -> CHOOSE       -> 1: :orbit: xxx_km

\<<
IF DEPTH NOT THEN DATE TIME END
ZT\|>JD
CLLCD
"CHOOSE OBJECT"
{ { "Planet"   1. }
  { "Asteroid" 2. }
  { "Comet"    3. } }
1. CHOOSE
IF NOT THEN DROP KILL END      @ "Cancel"led
CASE DUP 1. ==   @ Planet...
     THEN DROP JD\->T
          "CHOOSE PLANET"
          { { "Mercury"   1. }
            { "Venus"     2. }
            { "Earth"     3. }
            { "Mars"      4. }
            { "Jupiter"   5. }
            { "Saturn"    6. }
            { "Uranus"    7. }
            { "Neptune"   8. } }
            3 CHOOSE
           IF NOT THEN DROP KILL END      @ "Cancel"led
           @ T n_planet
           DUP2 SWAP OrbEl 3. DROPN ROT DROP
           @ T n_planet a e
           ROT NEG 4. ROLL PlanPos ROT ROT DROP2
           @  a e r
     END
     2. ==
     THEN                     @ perform Asteroid stuff
          "CHOOSE ASTEROID"
          ASTEROID.DAT
            1. CHOOSE.T
          IF NOT THEN DROP KILL END      @ "Cancel"led
          @ JD { Name Equin Y.FPepoch Mo w Omega i a e H G }
          EVAL DROP2 5. ROLLD 5. ROLLD
          @ JD  Name Equin Y.FPepoch Mo a e w Omega i
                8. ROLL 9. ROLL 5. DROPN  DUP2
          @ JD   Y.FPepoch Mo  a e a e
          7. ROLL 7. ROLL Y.FP\|> UT\|>JD -
          @  Mo  a e a e t-T
          0.9856076686 4PICK DUP \v/ * / *  6. ROLL +
          @   a e a e M
          F29.12 SWAP DROP
        @ a e r
     END
     @ must be 3...: perform Comet stuff:
          "CHOOSE COMET"
          COMET.DAT
            1. CHOOSE.T
          IF NOT THEN DROP KILL END      @ "Cancel"led
          @ JD { Name Equin Y.FPperi w Omega i q e H10 }
          OBJ\-> DROP2 5. ROLLD 5. ROLLD 3. DROPN 5. ROLL 5. ROLL DROP2
          @ JD  Y.FPperi q e
          0.999999999 MIN   @ this is a problem for parabolae and hyperbolae!!!
          ROT Y.FP\|> UT\|>JD NEG 4. ROLL +
          @  q e  t-T
          ROT 1. 4. PICK - / ROT DUP2
          @ t-T a e a e
          5. ROLL 0.9856076686 4. PICK DUP \v/ * / *
          @ a e a e M
          F29.12 SWAP DROP
        @ a e r

END

@ Main program: same for all bodies.
@ Stack: a e r
INV 3. PICK 2. * INV - \v/ 42.1219_km/s * 2. RND "V" \->TAG
@ Stack:  a e V
OVER DUP 1. + 1. ROT - / \v/
@ Stack:  a e V SQRT((1.+e)/(1.-e))
29.7847_km/s 5. PICK \v/ / DUP2 * 2. RND  "Vp" \->TAG
SWAP ROT                        / 2. RND  "Va" \->TAG
@ Stack:  a e V Vp Va
@ Apply Ramanujan's formula for Ellipse length
5. ROLL 1. 6. ROLL SQ - \v/ OVER *
@ Stack:  V Vp Va a b
DUP2 + 3. *
3. PICK 3. PICK 3. * +
4. ROLL 3. * 4. ROLL +
* \v/ - \pi * \->NUM 2. RND 1_au * "length" \->TAG
\>>

