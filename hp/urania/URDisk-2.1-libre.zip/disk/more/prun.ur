%%HP: T(3)A(D)F(.);

@ PRUN, (c) 1995, 1996 Georg ZOTTI, VIENNA
@ V2.1, 5.1.2000 adapted for Urania V2.1

@ PRUN draws planetary tracks along the ecliptic

@ No stack change!            =========================================
@ or  1: Date           ->   ||P l a n e t     g e o c e n t r i c    ||
@ Graph: centerline ecliptic ||                                       ||
@        Sun running along   ||                                       ||
@        Planets' tracks     ||������...............���������.........||
@                            ||______________ <-_ O___________________||
@                            || ........           ............     ..||
@                            ||         ������������           �����  ||
@                            ||                                       ||
@                            || D a t e :                             ||
@                             =========================================

@ Planet positions of low accuracy.

@ Menu driven program:
@ 1.) Select Planet: Mercury...Neptune
@ 2.) Resting: Coord.Sys. / Sun
@ 3.) Planet Track?   Yes / No
@ 4.) Date of start?   Today / Enter Date
@ 5.) Step (Days)? 1 / 5 / 10 / Other
@ Then, the requested track will be plotted (ca.1 point/s)
@ Program quits with [ON]/CANCEL

@ Changed flags and old stack will be restored.


\<< IF DEPTH NOT THEN DATE END
    DEPTH ROLLD DEPTH 1 - \->LIST                     @ old stack w/o date
    SWAP                                              @ fetch Date
    RCLF DUP 2 # 0h PUT STOF                          @ del user flags
@ {ostk} Date Flags

-16 CF DEG                                            @ Cartesian, Degrees

CLLCD
"CHOOSE PLANET" { { "Mercury"   1 }
                  { "Venus"     2 }
                  { "Mars"      4 }
                  { "Jupiter"   5 }
                  { "Saturn"    6 }
                  { "Uranus"    7 }
                  { "Neptune"   8 } }
-2 CHOOSE.T
IF NOT THEN STOF DROP OBJ\-> DROP KILL END      @ "Cancel"led

2 GET

@ {ostk} Date Flags PlNr

13 "STATIONARY " { { "Ecl.coord.sys." CF }
                   { "Sun"            SF } }
-1 CHOOSE.T
IF NOT THEN DROP2 STOF DROP OBJ\-> DROP KILL END  @ "Cancel": drop 13, PlNr
2 GET EVAL                                        @ work on flag

@ {ostk} Date Flags PlNr

14 "PLANET LEAVES TRACK?" { { "Yes" CF }
                            { "No"  SF } }
-1 CHOOSE.T
IF NOT THEN DROP2 STOF DROP OBJ\-> DROP KILL END  @ "Cancel": drop 14, PlNr
2 GET EVAL                                        @ work on flag

@ {ostk} Date Flags PlNr

"Step (days) ?" {  1 5 10
                { "Other" \<< "Enter step"
                { ":(Days):" V } INPUT OBJ\-> \>> } }
-3 CHOOSE.T
IF NOT THEN ROT DROP2 STOF OBJ\-> DROP KILL END  @ "Cancel": drop Date, PlNr
IF DUP TYPE 5 == THEN 2 GET EVAL END             @ read step

@ {ostk} Date Flags PlNr Step

6 FIX                                           @ for Date format AA.BBYYYY

4 ROLL 0 UT\|>JD
@ {ostk} Flags PlNr Step JDstart
                              0 0 0   0    { # 130d # 63d } { # 51d # 63d }
\-> oStk Flg pl step  jd      T L \Gl \Gb      oldS             oldP

\<<
IFERR

# 131d # 64d PDIM  ( 368, -10 ) PMIN ( -2, 10 ) PMAX   @ prepare PICT

PICT { # 0d # 0d }
{ "Mercury" "Venus" 0 "Mars" "Jupiter" "Saturn" "Uranus" "Neptune" }
pl GET " geocentric" + MAKE$22 2 \->GROB REPL

{ # 0d # 0d } PVIEW
(360,0) (0,0) LINE
IF 13 FS? THEN PICT 180 0 R\->C C\->PX { # 3d # 3d } - @ resting Sun
               GROB 7 7 C12214941422C1 REPL
          END

jd 5373483 FOR n                             @ Start date to max.9999

n JD\->T 'T' STO
-3 T PlanPos 3 PICK 'L' STO 3 \->LIST

pl NEG T PlanPos 3 \->LIST F32.1 F32.24 DROP

IF DUP ABS 9 > THEN SIGN 9 * END                 @ Max.� limitation
'\Gb' STO  '\Gl' STO                             @ Beta, Lambda in �

@ Calc. finished !  Now plot !

PICT oldP GROB 2 2 3030 GXOR                            @ Erase Planet

IF 14 FC? THEN PICT oldP GROB 1 1 10 GXOR END           @ Track on? leave dot
PICT \Gl
IF 13 FC? THEN PICT oldS GROB 7 7 C12214941422C1 GXOR   @ erase old sun
               PICT                                     @ plot new sun
               L 180 + 360 MOD 0 R\->C C\->PX { # 3d # 3d } -
               DUP 'oldS' STO                           @ store old Pos.
               GROB 7 7 C12214941422C1 GXOR
          ELSE L - 360 MOD END
\Gb R\->C DUP 'oldP' STO GROB 2 2 3030 GXOR             @ Planet point

PICT { # 2d # 57d } "Date: "
n JD\|>UT DROP SPLITDATE DAT$ + "  " + 2 \->GROB REPL  @ Show Date


step STEP                                               @ next run!

THEN CLEAR                                              @ IFERR  trap
END
oStk OBJ\-> DROP Flg STOF                               @ Stack, Flags...
\>>                                                     @ ...restored
\>>


