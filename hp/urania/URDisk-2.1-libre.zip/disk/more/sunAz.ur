%%HP: T(3)A(D)F(.);

@ SunAz finds Azimuths of rising and setting sun.
@ Altitudes of sun, date (default: current)  and latitude (default: Lat) can be adjusted in INFORM.
@ (c) 2004 by Georg ZOTTI
@ Method from Wolfhard Schlosser, Jan Cierny: Sterne und Steine (Eine
@ praktische Astronomie der Vorzeit). Wiss. Buchgesellschaft, Darmstadt 1996

@              2: :Az[NESW],\|^: DDD.ddd
@ 1: (date) -> 1: :Az[NESW],\|v: DDD.ddd

\<< 
IF DEPTH NOT THEN DATE END
@ date

"Solar Azimuth"
{{"Date"  "Calendar date" 0. }
 {"Greg?" "Force Gregorian Calendar" 0. }
 {"Lat"   "Geographical Latitude" 0. }
 {"Hsun"  "Sun's altitude above horizon" 0. }
}
1.
4. ROLL 1. Lat -.85 4. \->LIST
DUP 
INFORM
IF NOT THEN DROP KILL END
OBJ\-> DROP 

@ date greg? Lat h

4. ROLL IF 4. ROLL
        THEN @ force Gregorian: Use Calendarium to make JD
             GR\-> \->JD
        ELSE 0. UT\|>JD
        END
@ Lat h JD
JD\->T 
DUP 0. SunPos DROP ROT T\->\Geo \Gl\Gb\Ge\->\Ga\Gd SWAP DROP

@ lat h dec
90. SWAP - 3. ROLLD
DUP2 - ROT COS ROT COS *
@ E F cos(lat)cos(h)
3. ROLLD DUP2 + 2. / SIN
3. ROLLD - 2. / SIN *
SWAP /

IF DUP 0. <
THEN "always" "higher" 
ELSE \v/ 
     IF DUP ABS 1. > 
     THEN "always below"
     ELSE ACOS 2. * 
          180. OVER - "Az[NESW],\|^" \->TAG
          180. ROT  + "Az[NESW],\|v" \->TAG
     END
END

\>>

