%%HP: T(3)A(D)F(.);

@ A\delta\->a computes altitude from given Azimuth and declination
@ (c) 2006 by Georg ZOTTI

@ Developed from formulae of spherical Trigonometry,  e.g. Neugebauer.
@ 2: Azimuth_NESW
@ 1: declination_HH.MMSS     -> 1: { :altitude: DDD.ddd :altitude: DDD.ddd }
@                                  (list with 0..2 entries)

\<< \-> Az \Gd
  \<< \Gd HMS\-> '\Gd' STO
    Az COS Lat TAN /  ATAN  ABS @    IF DUP 180. > THEN 360. SWAP - END 
    Lat SIGN *                      @ altitude_of_equator
    \Gd SIN OVER COS * Lat SIN / ASIN @ h0 delta -- Delta_h 
    \-> h0 \GDh 
    \<<
     IF \Gd ABS Lat ABS < @ normal case
     THEN  \GDh h0 Az COS SIGN * + @   IF Az COS 0 < THEN + ELSE - END  @ singular solution
     ELSE 
       IF \Gd COS Lat COS / ASIN   COS \Gd SIGN *      Az COS  IF \Gd 0 > THEN > ELSE < END % cos(greatestDigression).GT.cos(Az)?
       THEN "No Solution" % no solution (digression .LT. Az!)
       ELSE \GDh 180. \GDh - 2 \->LIST 
            1.
	    \<< h0 IF Az COS 0. < THEN + ELSE - END 360. MOD IF DUP 180. > THEN 360. - END \>> 
	    DOLIST
       END
     END
    \>>
  \>>
\>>
