%%HP: T(3)A(D)F(.);

@ CalDat computes important calendarical propertiews for a year.
@ (c) 2005 by Georg ZOTTI
@ Method from Manfred Oswalden, "Was besagen die Kalendergr��en?",
@             Wiss.Nachr. 125, p.43f, Jul/Aug 2004.

@              2: :Hel. Rise, \Gl\164=DD.dd: Date
@ 1: (year) -> 2: :Hel. Set,  \Gl\164=DD.dd: Date

\<< 
IF DEPTH NOT THEN DATE SPLITDATE SWAP DROP SWAP DROP END
IP @ make sure year is integer!

@ year 

\-> J \<< 

 J 8. + 28. MOD 1. + "SolarCircle" \->TAG

 J 100. MOD @ r
 J 100. / IP @ s
 4. MOD @ a
 @ r a
 2. * OVER 6. * + SWAP 4. / IP 6. * + 7. MOD  1. + 
"ABCDEFGA" SWAP
IF J LEAPYR 
THEN DUP2 1. + DUP SUB ROT ROT DUP SUB +
ELSE DUP SUB
END
"Dominical" \->TAG

J 19. MOD 1. + "GoldenNumber" \->TAG

J 100. / IP @ s

OVER 11. * 27. + OVER 29. * + OVER 4. / IP + SWAP 8. * 13 + 25. / IP + 30. MOD
"Epact" \->TAG

CASE DUP 12. \<= THEN 13. OVER - 4. END
     DUP 23. \<= THEN 44. OVER - 3. END
     DUP 24. ==  THEN 18. 4. END
     DUP 25. ==  THEN IF J 19. MOD 10. > THEN 17. ELSE 18. END  4. END
     43. OVER - 4.
END J BINDDATE "Easter" \->TAG

21. 3. J BINDDATE OVER \GDDAY "FestNr(Character)" \->TAG

J 2. + 15. MOD 1. + "Roman TaxNr" \->TAG

{ "Saturn" "Jupiter" "Mars" "Sun" "Venus" "Mercury" "Moon" }
J 2. + 7. MOD 1. + GET "Regent" \->TAG

\>>
\>>

