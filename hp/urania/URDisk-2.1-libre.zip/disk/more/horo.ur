%%HP: T(3)A(D)F(.);

@    ==========================================================================
@  ==X                                                                        X==
@ ||  OX     O    XOX        OOOOOO  O           O     O     O  OOOOOO   XOOX   ||
@ ||  OOX    O   O   O       O       O          O O    OO   OO  O       O    O  ||
@ ||  O OX   O  OO   OO      O       O         O   O   O O O O  O       OX      ||
@ ||  O  OX  O  O     O      OXXX    O        OXXXXXO  O O O O  OXXX      OOX   ||
@ ||  O   OX O  O     O      O       O        O     O  O  O  O  O            O  ||
@ ||  O    OXO  O     O      O       O        O     O  O  O  O  O            O  ||
@ ||  O     OO   O   O       O       O        O     O  O     O  O       X    O  ||
@ ||  O      O    OXO        O       OXXXXXX  O     O  O     O  OXXXXX   OXXO   ||
@  ==X                                                                        X==
@    ==========================================================================

@
@ HORO is a program for astrologically (sic!) interested people to compute
@ their SIGNS and Ascendents (If I guessed correctly...)

@ THIS PROGRAM IS NOT REALLY USEFUL. IT JUST HELPS ANSWERING QUESTIONS BY
@ STRANGE MINDED PEOPLE. 
@ WHOEVER DISLIKES IT: PURGE (HP48) = DEL (PC-DOS, OS/2) = rm (UN*X)
@ V2.1: now uses array with constellation numbers. (smaller!)

\<< IF DEPTH 2 < THEN DATE TIME END

DUP2 ZT\|>JD JD\->T 0 SunPos DROP2         @ True Long of Sun

3 ROLLD
ECLHOR  DROP2                     @ Point of ecliptic on eastern horizon

0 1 FOR i
	[ 7 78 38 22 46 86 48 72 77 12 5 67 ] 
@        { "Aries"  "Taurus"  "Gemini"      "Cancer"      "Leo"      "Virgo"
@          "Libra"  "Scorpio" "Sagittarius" "Capricornus" "Aquarius" "Pisces" }
          ROT 30 / IP 1 + GET CstName
          i  "Ascend" "Sign" IFTE  \->TAG
    NEXT

\>>

