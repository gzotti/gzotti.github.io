%%HP: T(3)A(D)F(.);

@ DIST.PRT  finds (using GEODIST) the distance between 2 sites in :0:SITE.DAT.
@ (c) 1995, 1996 by Georg ZOTTI
@ upload e.g. with "kermit s DIST_PRT.U48 DIST.PRT"
@ V2.1: just uses the renamed entries and changed default port to 1.

\<< CLLCD
    0 1 FOR i i "TO" "DISTANCE FROM" IFTE       @ i is first 0, then 1!
         :1: SITE.DAT RCL
         IF DUP TYPE 5 \=/ THEN EVAL END @ ? :1:SITE.DAT could only reference
         1 CHOOSE.T                      @    e.g. :8:SITE.DAT.ALL
         IF NOT
         THEN IF i THEN DROP2 END
              0 DOERR
         END
         2 GET OBJ\-> 3 DROPN
    NEXT
    GEODIST
    "Dist" \->TAG
\>>

