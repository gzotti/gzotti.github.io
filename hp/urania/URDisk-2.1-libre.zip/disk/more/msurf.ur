%%HP: T(3)A(D)F(.);

@ MSURF is a very useful program to demonstrate usage of \164ALTITD.M in Moon/48.
@ It allows selection of a lunar site, for which the altitude of the Sun
@ either for the current time (empty stack) or for a given time (date,
@ time on stack) will be calculated.
@ Add more lunar sites if you like to!
@ (c) 1995, 1996 by Georg ZOTTI
@ 25.1.1998: changed Ptolemaios -> Ptolemaeus
@ 5.1.2000: V2.1, only adapted to Urania V2.1

\<< IF DEPTH 2 < THEN DATE TIME END

"SELECT LUNAR AREA"
{ { "Apollo 11"         (  23.2  ,   0.6  )  }
  { "Apo.12 & Surv.3"   ( -23.2  ,  -3.   )  }
  { "Apollo 14"         ( -17.3  ,  -3.7  )  }
  { "Apollo 15"         (   3.5  ,  26.1  )  }
  { "Apollo 16"         (  15.3  ,  -9.   )  }
  { "Apollo 17"         (  30.8  ,  20.07 )  }
  { "Archimedes"        (  -4.   ,  30.   )  }
  { "Aristarchus"       ( -48.   ,  23.   )  }
  { "Aristillus"        (   1.   ,  34.   )  }
  { "Aristoteles"       (  17.   ,  50.   )  }
  { "Arzachel"          (  -2.   , -18.   )  }
  { "Bullialdus"        ( -22.   , -21.   )  }
  { "Clavius"           ( -14.   , -58.   )  }
  { "Copernicus"        ( -20.   ,  10.   )  }
  { "Eudoxus"           (  16.   ,  44.   )  }
  { "Fracastorius"      (  33.   , -21.   )  }
  { "Hyginus"           (   6.   ,   8.   )  }
  { "Kepler"            ( -38.   ,   8.   )  }
  { "Langrenus"         (  61.   ,  -9.   )  }
  { "Linn\233"          (  12.   ,  28.   )  }
  { "Messier"           (  48.   ,  -2.   )  }
  { "Petavius"          (  60.   , -25.   )  }
  { "Plato"             (  -9.   ,  51.   )  }
  { "Ptolemaeus"        (  -2.   ,  -9.   )  }
  { "Rupes Recta"       (  -7.5  , -22.   )  }
  { "Theophilus"        (  26.   , -11.   )  }
  { "Tycho"             ( -11.   , -43.   )  }
  { "Sinus Iridum"      ( -31.   ,  44.   )  }
}
DUP SIZE 2 /            @ Selection starts in the middle position

CHOOSE.T
IF NOT THEN 0 DOERR END
2 GET C\->R 4 ROLL 4 ROLL \164ALTITD.M

\>>

