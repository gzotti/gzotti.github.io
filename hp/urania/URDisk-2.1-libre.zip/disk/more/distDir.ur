%%HP: T(3)A(D)F(.);

@ DISTDIR finds (using GEODIST) the distance and azimuth (direction)
@ between 2 sites in 'SITE.DAT'.
@ (c) 2002-2004 by Georg ZOTTI
@ Direction formula taken from a document on quibla direction:
@ http://www.patriot.net/~abdali/ftp/qibla.pdf p.17 

\<< CLLCD
    0 1. FOR i i "TO" "DISTANCE FROM" IFTE       @ i is first 0, then 1!
              SITE.DAT
              1. CHOOSE.T
              IF NOT
              THEN IF i THEN DROP2 END
                   0 DOERR
              END
              2. GET OBJ\-> 3. DROPN
    NEXT
    4. DUPN GEODIST "Dist" \->TAG 5. ROLLD

\-> l b lk bk
 \<<
   lk l - DUP SIN
   b COS bk TAN * ROT COS b SIN * - ATN2 360. MOD 
 \>>   
 3. RND "Az[NESW]" \->TAG
\>>








