%%HP: T(3)A(D)F(.);

@ SYSTEM plots the Solar system from the North pole of the ecliptic.
@ Coordinate cross at lower right indicates cardinal ecl. directions.
@ V2.1, 5.1.2000, adapted for Urania V2.1

@ 1: Date ( or 1: -- -> current Date) -> PICT

\<< IF DEPTH NOT THEN DATE END
RCLF SWAP
OVER 2 # 0h PUT STOF                       @ del user flags
DEG  -27 CF                                @  (x,y) mode
{ -15 -16 -19 } SF                         @ ->V2 makes complex number
13 "Area of Solar System ?" { { "Mercury-Saturn"  CF }
                              { "Earth-Neptune"   SF } }  1
CHOOSE.T
IF NOT THEN DROP2 STOF KILL END                 @ "Cancel": drop 13, Date
2 GET EVAL                                      @ work on flag

@ on Stack now: (Old_contents /) Old_flags / Date

# 131d  # 131d PDIM
POLAR

                                                @ for Date format AA.BBYYYY
"Date: " OVER SPLITDATE DAT$ + STD
PICT { #  5d # 124d } ROT 2 \->GROB REPL
PICT { # 25d # 0d } "SOLAR   SYSTEM" 2 \->GROB REPL

{ # 0d # 0d } PVIEW

@ In Stack still: (old_content /) Old_Flags / Date

0 UT\|>JD JD\->T

\-> Flg T
\<<
13 FC?
{ 1 6 ( 10, 10 ) ( -10, -10 ) }         @ inner/outer system,
{ 3 8 ( 35, 35 ) ( -35, -35 ) }         @ range in AU
IFTE                                    @ does << LIST-> DROP >>
PMIN PMAX

PICT (0,0) C\->PX { # 2d # 2d } - GROB 4 4 60909060 REPL   @ Sun

FOR pl pl NEG T PlanPos SWAP DROP
    PICT
   { GROB 3 6 502050207020     GROB 3 5 2050207020      @ Planet  GROB
     GROB 3 5 2070205020       GROB 6 6 8303E2909060    @ smaller than GROBs
     GROB 5 6 30A090F18080     GROB 5 7 30A06121218040  @ from PLANGROB
     GROB 5 8 40E051E0115111E0 GROB 5 5 5151F14040   }

    pl GET
    ROT 4ROLL \->V2 C\->PX                              @ Coordinates
    OVER SIZE 2 \->LIST 2 / -                           @ Corr.f.GROB-Size
    SWAP GOR
NEXT

PICT { # 117d # 115d }                                  @ Coord.Cross
GROB 14 16 0C0002000400080006000000246354807F90548054800110011005100B100110
GOR

Flg STOF
\>>
Scroll.T
\>>


