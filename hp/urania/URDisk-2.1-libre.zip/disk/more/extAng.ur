%%HP: T(3)A(D)F(.);

@ extAng finds the extinction angle (limiting altitude) of an astronomical object.
@ Magnitude of object, limiting magnitude in zenith and air extinction coefficient can be adjusted in INFORM.
@ (c) 2004 by Georg ZOTTI
@ Method from Bradley Schaefer, Sky&Telescope, 04/1987 p426

@ DOES NOT WORK! ACCORDING TO PROF. FIRNEIS, SCHAEFER IS GOOD BUT HIS PROGRAMS NEVER WORK.

@ 3: ((lim.mag.at zenith))
@ 2: ((extinction coefficient))
@ 1: (mag)                        -> 1: :Ext. Altitude: DDD.ddd

@ if 0 or less than 3 values on stack, INFORM is shown, with mag given entered
@ in the INFORM

\<< 
IF DEPTH NOT THEN 2. END @ default value 2 for star magnitude

IF DEPTH 3. <
THEN
  "EXTINCTION ALTITUDE" 
  {{"Object's Magnitude"      "Object's magnitude" 0. }
   {"Limiting Magnitude"      "Limiting magnitude at zenith" 0. }
   {"Extinction Coefficient"  "0.1=mountain 0.2\0310.5=lowland" 0. }
  }
  1.
  4. ROLL 6.0 0.25 3. \->LIST @ default values
  DUP 
  INFORM
  IF NOT THEN KILL END
  OBJ\-> DROP 
END
@ mag lim ext

\-> M M0 K
  \<< 
      @ find background
      IF M0 K + 4.21 < THEN 0.00000126 -8.35  ELSE 0.0126 -9.80 END @ K0 C
      2.5 * K + 16.57 + M0 + -5.0 / @ K0 X0
      ALOG 1. - SQ SWAP / K 118.0 * 0.2 / - @ B0
       
      @ find desired airmass
      K 0.2 / 236. *  + @ B
      IF DUP 1650. > THEN 0.00000126 -8.35 ELSE 0.0126 -9.80 END @ B K0 C
      3. ROLLD * SQ 1. + LOG 2. * + @ I
      2.5 * 16.57 + M + K NEG /   @ A
  
      @ find ext. angle: loop over zenith distance
      90.1  
      \-> A Z 
      \<<
          DO -0.1 'Z' STO+
  	   Z COS DUP -11. * EXP 0.025 * + @ X
  	UNTIL
  	   INV A \<=
  	END
  	90.0 Z - "Ext. Altitude" \->TAG
      \>>
  \>>
\>>

