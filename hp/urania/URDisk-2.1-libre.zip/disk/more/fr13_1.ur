%%HP: T(3)A(D)F(.);

@ Fr13.1 is an alternative version of Fr13 for Urania.
@ Fr13 is an example how to use date arithmetic of Urania.
@ This one can be useful to warn superstitious people or others
@ interested in the date "Friday the 13.", but is can be changed easily.

@ 1: YYYY   ->   1: :Fr.13,YYYY: { 13.mm 13.mm ... }
@                   ( Result as list in ONE level! )

@ V2.1 Changed for new behavior on WDAY

\<<
 IF DEPTH NOT THEN DATE 100 * FP 10000 * END
 \-> y
 \<< { }
    1 12 FOR m 13 m
@             IF -42 FC? THEN SWAP END
@             100 / y 1000000 / + +
             y BINDDATE
             IF WDAY OBJ\-> SWAP DROP "Friday" ==
             THEN 13 m
                  IF -42 FC? THEN SWAP END
                  100 / + +
             END
         NEXT
    "Fr.13," y + \->TAG
  \>>
\>>
