%%HP: T(3)A(D)F(.);

@ QIBLA finds the azimuth of Mecca, important for muslims.
@ Based on formula (1) from 
@ http://www.patriot.net/~abdali/ftp/qibla.pdf p.17 
@ This is the great circle direction to Mecca, and the most believable source.
@ (c) 2004 Georg ZOTTI 12.12.2004

\<<
IF DEPTH 2. < THEN Long Lat END  @ default: current site
39.823333 21.423333              @ l_mekka b_mekka
\-> l b lk bk
 \<<
   lk l - DUP SIN
   b COS bk TAN * ROT COS b SIN * - ATN2 360. MOD 
   3. RND "Az(Mekka)" \->TAG
 \>>   
\>>

