%%HP: T(3)A(D)F(.);

@ COMPASS.UR, compass pointers for Sun&Moon
@ Example program for Urania/48 and Urania/49 V2.1
@ 1999-06-11 G. Zotti

@ Earlier in 1999, I had a conversation with a PalmIII user 
@ (sorry, lost your name! Please email me). He told me 
@ of a PalmIII program that created a compass display with a pointer 
@ to the sun, given time and coordinates. 
@ Well, this is about the same idea, and works for Sun or Moon.

@ If (Sun|Moon) is above horizon, a line is drawn as pointer in the
@ correct direction. Length depends on object's altitude:
@ the lower - the longer. [changed in V1.1, see below]
@ If the object is below the horizon, just a dot indicates the
@ direction and altitude below horizon.

@ Generalization to other objects is left as an exercise for the user!
@ N.B. widely done in V2.1.1

@ as usual: 2: (Date)
@	    1: (Time)   -> graphics in PICT  -> -- 

@ V1.1,  08/1999: the pointer line length is now always maximum.
@ V2.1,  01/2000: adapted to Urania V2.1 and HP49. 
@ V2.1.1 07/2000: DIR->PRG; now also for stars and planets
@ V2.1.2 04/2007: Discerns HP50


\<< 

CLLCD
"SELECT TARGET"
{ { "Sun"     0. }
  { "Moon"    1. }
  { "Venus"   2. }
  { "Mars"    4. }
  { "Jupiter" 5. }
  { "Saturn"  6. }
  { "Star"    100. }
}
-1. CHOOSE.T
IF NOT THEN KILL END
RCLF SWAP DEG 
@ (date) (time) flags { "name" obj}
IF DEPTH 4. < THEN DATE TIME ROT ELSE 4. ROLL 4. ROLL ROT  END

EVAL SWAP 4. ROLLD
@ "name" date time obj

@ "name" date time obj -> "name" date time alpha delta
CASE
     DUP NOT THEN DROP @ sun 
                  DUP2 ZT\|>JD JD\->T 0. SunPos DROP \Gl\Gb\Ga\Gd
     END
     DUP 1. == THEN DROP @ moon
                    DUP2 ZT\|>JD JD\->T 0. MoonPos DROP2 \Gl\Gb\Ga\Gd
     END
     DUP 6. \<= THEN @ planet; date time pl
                3. PICK 3. PICK ZT\|>JD JD\->T @ dt tm pl T 
		3. OVER PlanPos 3. \->LIST     @ dt tm pl T {}
                ROT ROT PlanPos 3. \->LIST     @ dt tm {earth}{pl}
		F32.1 F32.24 DROP \Gl\Gb\Ga\Gd
     END
     @ default: star
     DROP ROT DROP FINDSTAR NEG GETSTRDAT EVAL ROT DROP SWAP
     ROT 5. ROLLD
END


@ altazimutal coodinates (decimal degrees everywhere!)
@ 4: Date          4: Date
@ 3: Time          3: Time
@ 2: RA         -> 2: azimuth
@ 1: decl          1: altitude

4. PICK 4. PICK \GhLOC ROT HMS- SWAP H\GdAa 


@ Aa\->P | find pixel coordinates from 2:Azimuth/1:Altitude -> 1:Compl
@ DUP2 90. OVER ABS - ROT D\->R 'i' * EXP * \->NUM C\->R SWAP R\->C 
@ new version: this will make the line always long.
DUP2 90. ROT D\->R 'i' * EXP * \->NUM C\->R SWAP R\->C 


@ do the drawings

# 83h # 40h BLANK 
{ # 4Ah # 8h } 
GROB 49 49 0000083000000000000830000000000008300000000000083000000000000830000000000008300000000000083000000000000830000000000008300000000000047000000000000470000000000004700000000000047000000000000470000000000004700000000000047000000000000470000000000002F0000000000002F0000000000002F0000000000002F00000000000E3FF00000000EFF770FF0000FFFFFF3000FF10FFFFFFFFFFFF10FF1008FFFFFF1000EF1CDFFF00000000EF9F00000000000E9000000000000E9000000000000E9000000000000E9000000000000C5000000000000C5000000000000C5000000000000C5000000000000C5000000000000C5000000000000C5000000000000C50000000000008300000000000083000000000000830000000000008300000000000083000000000000830000000000008300000000000083000000000000830000000 
REPL PICT STO 
{ # 0h # 0h } PVIEW
IF VERSION DROP 11 12 SUB "50" ==  
THEN (-300.,-150.) 
ELSE (-300.,-100.) 
END
PMIN (100.,100.) PMAX
(-90.,0.) (90.,0.) LINE
(0.,-90.) (0.,98.) LINE
IF SWAP 0. <
THEN C\->PX
     IF DUP PIX?
     THEN PIXOFF
     ELSE PIXON
     END
ELSE (0.,0.) TLINE
END 

@ finish graphics. 5:"Object"/4:Date/3:Time/2:Az/1:Alt -> --

PICT { # 4h # 3Ah } ROT  "Alt:" SWAP 2. REAL$ + 1. \->GROB REPL 
PICT { # 8h # 34h } ROT   "Az:" SWAP 2. REAL$ + 1. \->GROB REPL 
PICT { # 0h # 2Eh } ROT "Time:" SWAP TIM$ + 1. \->GROB REPL 
PICT { # 0h # 28h } ROT "Date:" SWAP SPLITDATE DAT$ + 1. \->GROB REPL 
PICT { # 0h #  0h } ROT 2. \->GROB REPL 
PICT { # 60h # 0h } "N" 2. \->GROB GOR

STOF { } PVIEW
\>>
