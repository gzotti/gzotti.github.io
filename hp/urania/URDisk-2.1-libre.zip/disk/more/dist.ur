%%HP: T(3)A(D)F(.);

@ DIST  finds (using GEODIST) the distance between 2 sites in 'SITE.DAT'.
@ (c) 1995, 1996 by Georg ZOTTI
@ V2.1: just changed the entries.

\<< CLLCD
    0 1 FOR i i "TO" "DISTANCE FROM" IFTE       @ i is first 0, then 1!
              SITE.DAT
              1 CHOOSE.T
              IF NOT
              THEN IF i THEN DROP2 END
                   0 DOERR
              END
              2 GET OBJ\-> 3 DROPN
    NEXT
    GEODIST
    "Dist" \->TAG
\>>
