%%HP: T(3)A(D)F(.);

@ PALT shows altitudes of the planets very quickly
@ Works only after 1582-10-15 ! (uses TSTR)
@ (c) 1995, 1996 Georg ZOTTI
@ V2.1, 5.1.2000, just adaptions for Urania V2.1

\<<
PICT PURGE (0,-60) PMIN (10,130) PMAX
IF DEPTH 2 <
THEN DATE TIME                                          @ default: current time
END
{ # 0h # 0h } PVIEW                                     @ show PICT

PICT { # 20d # 0d } "ALTITUDE OF PLANETS" 1 \->GROB REPL @ Title
DUP2 TSTR       PICT { # 26d # 59d } ROT  1 \->GROB REPL @ write date
(1, 60)  (9, 60) LINE PICT (0, 65) " 60"  1 \->GROB REPL @ alt. lines
(1, 30)  (9, 30) LINE PICT (0, 35) " 30"  1 \->GROB REPL
(1,  0)  (9,  0) LINE PICT (0,  5) "  0"  1 \->GROB REPL
(1,-30)  (9,-30) LINE PICT (0,-25) "-30"  1 \->GROB REPL

@ Earth data
DUP2 \GhLOC  \-> \Gh

\<<
ZT\|>JD JD\->T -3 OVER PlanPos 3 \->LIST

@ T {LoBoRo}

 1 8 FOR n
         IF n 3 \=/
         THEN PICT n .4 + 110 R\->C n PLANGROB REPL    @ Symbol
              DUP2 n NEG ROT PlanPos 3 \->LIST F32.1 F32.24 DROP

         ELSE PICT (3.4,110) 5 MOONGROB REPL    @ Symbol
              OVER 0 MoonPos DROP2
         END
         \Gl\Gb\Ga\Gd \Gh ROT HMS- SWAP H\GdAa SWAP DROP
         n .5 + SWAP IF DUP 0 <
                     THEN DUP -30 MAX                       @ Below -30�:
                          IF SWAP -30 <
                          THEN PICT n .45 + -33 R\->C       @ draw downArrow 
                               GROB 3 2 7020 REPL
                          END
                     END
                R\->C n .5 + 0 R\->C LINE
     NEXT
     DROP2
 \>>
{ } PVIEW
\>>







