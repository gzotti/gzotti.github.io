%%HP: T(3)A(D)F(.);

@ WDSRCH is an extension of FR13. It allows search of every week day.
@ User is asked for a date and a week day. The program finds all dates
@ with this week day for the following years.

@ 1: YYYY    ->                    -> Text GROB
@ (1:   --   -> current year)

@ Changed for Urania V2.1+: new behavior of WDAY

\<<
  IF DEPTH NOT THEN DATE 100 * FP 10000 * END
"Enter date for which
a week day shall be
found  ("
-42 FS? "DD.MM)" "MM.DD)" IFTE +
""
INPUT OBJ\->
"WEEK DAY ?"
{ "Monday" "Tuesday" "Wednesday" "Thursday" "Friday" "Saturday" "Sunday" }
-1
CHOOSE.T

  IF
  THEN 0 RCLF
       \-> j dt wd pos of
       \<< -40 CF 6 FIX
           CLLCD
           IFERR
                 DO dt j 1000000 / + DUP WDAY OBJ\-> SWAP DROP
                    IF wd ==
                    THEN pos 1 + DISP pos 1 + 6 MOD 'pos' STO
                         IF pos NOT
                         THEN 0 WAIT DROP
                         END
                    ELSE DROP
                    END
                    1 'j' STO+
                 UNTIL j 9999 ==
                 END
           THEN DROP of STOF
           END
       \>>
  ELSE DROP2
  END
\>>

