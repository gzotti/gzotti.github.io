%%HP: T(3)A(D)F(.);

@ DIAL calculates and draws a flat sundial. Meeus, Ch.56
@ HP-48GX and HP-49G only. HP-48SX users have to replace INFORM masks with INPUTs.

@ The graphic represents the dial of a flat sundial right on the
@ calculator's screen. You would need a perpendicular pin (gnomon)
@ of length L (Field 4 in INFORM mask) in the dial's center. It might have
@ another stick attached which leads to the intersetion of the hour lines.
@ If this connection (style) exists, it shows the solar time. If not, then only
@ the tip of the pole's shadow gives the time.

@ Technical notes: 
@ Uses User Flag 11, restores all flags.
@ Action: do calc 2 * : 1. Hour lines, 2. Altitude lines

@ Version 1, 25.8.1995, Georg ZOTTI
@ Version 1.1, 5.9.1999: moved source code to Linux/plainASCII
@                        still very bad not to save the points. VOLUNTEERS?
@ Version 2.1, 5.1.2000: only adapted to Urania V2.1 and HP49.
@ CHANGES from V1.1 for U2.0: now calls Scroll.T

\<<
"FLAT SUNDIAL"
{ { "Lat" "GEOGRAPHIC LATITUDE (-90<Lat<90)"   0 }
  { "AZ"  "AZIMUTH (0=NORTH, 90=EAST)"         0 }
  { "z"   "INCLINATION (0=HORIZ. 90=VERT.)"    0 }
  { "L"   "LENGTH OF GNOMON (CM)"              0 } }
{ }
Lat { 180 90 1 } + DUP
INFORM
IF NOT
THEN 0 DOERR
END OBJ\-> DROP

ROT 180 + 360 MOD
              0     0 0  0   0   0 (0,0) (0,0) (0,0)
\-> phi z a D delta P Q1 Ny1 Ny2 Q xy    xyold xyo
\<< RCLF                                        @ kept on stack
    # 131d DUP PDIM
    3.05 a / DUP R\->C DUP PMAX NEG PMIN         @ LCD is ca. 6.1 cm wide
    { # 0d # 0d } PVIEW
    phi SIN z COS *  phi COS z SIN * D COS * -  'P' STO
    phi COS z COS *  phi SIN z SIN * D COS * +  'Q1' STO  @ Q1, Ny1, Ny2 constant !
    phi COS z SIN *  phi SIN z COS * D COS * - 'Ny1' STO
    phi SIN z SIN *  phi COS z COS * D COS * +  DUP 'Ny2' STO
    IF   P
    THEN a * P / NEG                                       @ yo
         a P / phi COS * D SIN *  SWAP R\->C 'xyo' STO       @ (xo,yo)
    ELSE DROP
    END

    @ Altitude lines:
    1 7 FOR dec [ -23.44 -20.15 -11.47 0 11.47 20.15 23.44 ] dec GET 'delta' STO
        IF   phi delta - ABS 90 <     @ Polar area: H would be complex!
        THEN
          11 CF
          phi TAN delta TAN * NEG -1 MAX 1 MIN ACOS  DUP NEG  SWAP FOR H
                   D SIN z SIN * H SIN * Q1 H COS * + P delta TAN * + 'Q' STO
                   IF Q 0 >
                   THEN D COS H SIN *
                        D SIN phi SIN H COS * phi COS delta TAN * - * - Q / a *   @ x
                        z COS D SIN * H SIN * Ny1 H COS * - Ny2 delta TAN * - @ Ny
                        Q / a *  R\->C  'xy' STO                          @ (x,y)
                        IF 11 FS? THEN xyold xy LINE END
                        xy 'xyold' STO
                        11 SF
                   ELSE 11 CF
                   END
          5 STEP    @ every 20 minutes
        END
    NEXT @ dec      Alt. lines done
    -180 180 FOR H
        11 CF
        1 7 FOR dec [ -23.44 -20.15 -11.47 0 11.47 20.15 23.44 ] dec GET 'delta' STO
                D SIN z SIN * H SIN * Q1 H COS * + P delta TAN * + 'Q' STO
                IF Q 0 >
                   phi TAN delta TAN * NEG -1 MAX 1 MIN ACOS DUP NEG H <
                                                       SWAP    H >   AND  AND
                THEN D COS H SIN *
                     D SIN phi SIN H COS * phi COS delta TAN * - * - Q / a *   @ x
                     z COS D SIN * H SIN * Ny1 H COS * - Ny2 delta TAN * - @ Ny
                     Q / a *  R\->C  'xy' STO                          @ (x,y)
                     IF 11 FS? THEN xyold xy LINE END
                     xy 'xyold' STO
                     11 SF
                ELSE 11 CF
                END
        NEXT
    15 STEP            @ H in deg -> 1 hour step

    PICT (0, 0) C\->PX { # 1d # 1d } - GROB 5 5 0050205000 REPL @ Center
    IFERR
         PICT xyo C\->PX { # 1d # 1d } - GROB 5 5 0050205000 REPL @ Style-Pos.
    THEN 3 DROPN   @ i.e. PICT, {}, GROB
    END
    (0,0) xyo LINE

    PICT  # 0d                 @ Decoration: On each sundial
                               @ should be a wise sentence!
    IF Ny1 0 <                 @ Zero above center?
    THEN  # 111d
    ELSE  DUP
    END
    2 \->LIST
    GROB 131 15 FF3000000000000000000000000000EF70203000000000000000000000000000602048FF0000000000000000000000008FF0108800FFFFF000000000000008FFFF708800090000000FFFFFFFFFFFFFF700000084000A00007420000000000000001C340082000900088468C3083801C30832140A00840088000804E840044411400442140110880048000074A9400402214004021C11108010280000842BC1083221C108321401108020FF0008842E40004221400042140A008F70080000742C40044411400442FC3400800008F7000008C308380FC3083200000FF0000008FFFF7000000000000000FFFFF00000000000008FFFFFFFFFFFFFFF0000000000
    REPL
\>>
STOF
Scroll.T
\>>

