%%HP: T(3)A(D)F(.);

@ QIBLA finds the azimuth of Mekka, 
@ important for muslims.
@ Based on algorithm found in Sternenbote 07/2002
@
@ (c) 2002 Georg ZOTTI
@  4.7.2002, just adaptions for Urania V2.1

\<<
IF DEPTH 2 <
THEN Long Lat                   @ default: current site
END

SWAP NEG

-39.82 21.43 @ l_mekka b_mekka
\-> b1 l1 l2 b2
\<<
    l2 l1 -  b2 COS OVER SIN OVER * @ Dl cosb2 sina.numerator
    3. PICK COS ROT b1 COS * *      @ Dl sina.numerator cosx.left
    b1 SIN b2 SIN * +
    ACOS SIN / ASIN                 @ Dl a

    b2 b1 -

@ Dl a Db

    CASE 3. PICK 0. > THEN CASE DUP 0. > THEN 360. ROT - END @ Dl Db A
                                DUP 0. < THEN 180. ROT + END @ Dl Db A
                                DROP 270. @ Dl a A
                           END
                      END
         3. PICK 0. < THEN CASE DUP 0. > THEN SWAP NEG END @ Dl Db A
                                DUP 0. < THEN SWAP 180. + END @ Dl Db A
                                DROP 90. @ Dl a A
                           END
                      END
         0. > 0. 180. IFTE @ Dl a A
    END
    3. ROLLD DROP2
@ A
    3. RND "Az(Mekka)" \->TAG
\>>   
\>>







