%%HP: T(3)A(D)F(.);

@ HELIACAL finds the dates of Heliacal Rising and Setting of a star. 
@ Altitudes of sun/star, year (default: current)  and latitude (default: Lat) can be adjusted in INFORM.
@ (c) 2004 by Georg ZOTTI
@ Method from Jean Meeus, Math. Astr. Morsels, Willmann-Bell 1997

@              2: :Hel. Rise, \Gl\164=DD.dd: Date
@ 1: (year) -> 2: :Hel. Set,  \Gl\164=DD.dd: Date

\<< 
IF DEPTH NOT THEN DATE 100. * FP 10000. * END
IP @ make sure year is integer!
IF FINDSTAR DUP NOT THEN DROP KILL END
@ year starName starNr 

"OBJECT ALTITUDES"
{{"Hsun" "Sun's altitude below horizon" 0. }
 {"Hstar" "Star's altitude above horizon" 0. }
 {"Year" "Calendar year" 0. }
 {"Lat" "Geographical Latitude" 0. }
}
1.
{ -7. 3. }
7. ROLL + Lat +
DUP 
INFORM
IF NOT THEN DROP2 KILL END
OBJ\-> DROP 

@ starName starNr h0 h year Lat
6. ROLLD 5. ROLLD 5. ROLLD 5. ROLLD
@ Lat h0 h year starName starNr 
GETSTRDAT OBJ\-> 5. DROPN 5. ROLL DROP
@ Lat h0 h year starName PM_RA PM_dec dec RA
6. PICK 2000. - SWAP
@ Lat h0 h year starName PM_RA PM_dec dec years RA2000
OVER 6. ROLL * 3600. / \->HMS HMS+
@ Lat h0 h year starName PM_dec dec years RA'2000
OVER 5. ROLL * 3600. / \->HMS 4. ROLL HMS+ 
@ Lat h0 h year starName years RA'2000 dec'2000
0. 4. ROLL 100. / DUP 6. ROLLD  Pre5
@ Lat h0 h year T_year starName RA'year dec'year
4. PICK T\->\Geo                     0.  0. 0.
\-> Lat h0 h year T name RA dec \Ge \Gl0 S  C
\<<
@ Find out ecl. longitude of star, i.e. lambda_0
RA dec \Ge \Ga\Gd\Ge\->\Gl\Gb DROP '\Gl0' STO

h SIN Lat SIN dec HMS\-> SIN * - Lat COS dec HMS\-> COS * / ACOS DUP NEG @ Hset Hrise

RA HMS\-> 15. * ROT OVER + @ Hrise RA_deg ThetaSet
3. ROLLD +
@ ThetaSet ThetaRise

1 2 FOR event

        Lat SIN \Ge SIN * Lat COS \Ge COS * 3. PICK SIN * + 'S' STO
        COS Lat COS * 'C' STO
        
        IF \Gl0 SIN 2. \v/ INV <
        THEN @ sun must be near 0 or 180 degrees
            \Gl0 
            DO  h0 SIN OVER COS C * - S / ASIN IF DUP COS SIGN 0. < THEN 180. SWAP - END
            UNTIL DUP ROT - ABS 360. MOD 0.1 <
            END
        ELSE @ sun must be near 90 or 270 degrees
            \Gl0 
            DO  h0 SIN OVER SIN S * - C / ACOS IF DUP SIN SIGN 0. < THEN NEG 360. MOD END
            UNTIL DUP ROT - ABS 360. MOD 0.1 <
            END
        END
        
        @ \Gl of Sun at moment of Hel. Rise.
        @ To find the date, we find date of spring equinox, simply assume a mean motion of the sun, 
        @ then we compute accurate sun position for 3 dates around the approximate and find 
        @ real date by interpolation.
       
        @ Stack: (ThetaSet)_if_event=1  \Gl_rise
        
        @ Now, find VERY approximate spring equinox date. Meeus, Astr.Alg. 2nd ed., ch27
        year 1000. / @ Y
        -0.00071 OVER * 0.00111 + OVER * 0.06134 + OVER * 365242.13740 + * 1721139.29189 + @ JDEo_spring
        OVER 360. 365.2422 / *  + @ very crude JD of sun being at \Gl.  
        
        DUP     10. - JD\->T 1 SunPos DROP2 3. PICK -
        OVER          JD\->T 1 SunPos DROP2 4. PICK -
        3. PICK 10. + JD\->T 1 SunPos DROP2 5. PICK -
        
        IF 3 PICK OVER > @ if wraparound over \Gl=zero
        THEN ROT 360. - 3. ROLLD
        END
        IF DUP2 > @ if wraparound over \Gl=zero
        THEN SWAP 360. - SWAP
        END
        
        3. \->LIST -10. INTER 10. * + @ JD of sun being at \Gl
        
        @ Stack: (ThetaSet)_if_event=1  \Gl_rise JD_\Gl_rise
        JD\|>ZT DROP 
        "Hel." {"Rise" "Set"} event GET + ", \Gl\164=" + ROT 2. RND + \->TAG
        SWAP
NEXT
\>>
SWAP @ just to put rise on level 2.
\>>

