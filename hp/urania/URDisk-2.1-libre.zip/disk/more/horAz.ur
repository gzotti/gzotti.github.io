%%HP: T(3)A(D)F(.);

@ HorAz finds Azimuths of rising and setting of a star.
@ Altitudes of star, year (default: current)  and latitude (default: Lat) can be adjusted in INFORM.
@ (c) 2004 by Georg ZOTTI
@ Method from Wolfhard Schlosser, Jan Cierny: Sterne und Steine (Eine
@ praktische Astronomie der Vorzeit). Wiss. Buchgesellschaft, Darmstadt 1996

@              2: :Az[NESW],\|^: DDD.ddd
@ 1: (year) -> 1: :Az[NESW],\|v: DDD.ddd

\<< 
IF DEPTH NOT THEN DATE 100. * FP 10000. * END
IP @ make sure year is integer!
IF FINDSTAR DUP NOT THEN DROP KILL END
@ year starName starNr 

"OBJECT: " ROT +
{{"Hstar" "Object's altitude above horizon" 0. }
 {"Year" "Calendar year" 0. }
 {"Lat" "Geographical Latitude" 0. }
}
1.
{ -.58 }
6. ROLL + Lat +
DUP 
INFORM
IF NOT THEN DROP2 KILL END
OBJ\-> DROP 

@ starNr h year Lat
4. ROLLD ROT
@ Lat h year starNr 
GETSTRDAT OBJ\-> 5. DROPN 5. ROLL DROP
@ Lat h year PM_RA PM_dec dec RA
5. ROLL 2000. - SWAP
@ Lat h PM_RA PM_dec dec years RA2000
OVER 6. ROLL * 3600. / \->HMS HMS+
@ Lat h PM_dec dec years RA'2000
OVER 5. ROLL * 3600. / \->HMS 4. ROLL HMS+ 
@ Lat h years RA'2000 dec'2000
0. 4. ROLL 100. /  Pre5
@ Lat h RA'year dec'year
SWAP DROP
@ lat h dec
90. SWAP - 3. ROLLD
DUP2 - ROT COS ROT COS *
@ E F cos(lat)cos(h)
3. ROLLD DUP2 + 2. / SIN
3. ROLLD - 2. / SIN *
SWAP /

IF DUP 0. <
THEN "always" "higher" 
ELSE \v/ 
     IF DUP ABS 1. > 
     THEN "always below"
     ELSE ACOS 2. * 
          180. OVER - "Az[NESW],\|^" \->TAG
          180. ROT  + "Az[NESW],\|v" \->TAG
     END
END

\>>

