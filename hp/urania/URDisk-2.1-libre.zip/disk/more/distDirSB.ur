%%HP: T(3)A(D)F(.);

@ DISTDIR finds (using GEODIST) the distance and azimuth (direction)
@ between 2 sites in 'SITE.DAT'.
@ (c) 2002 by Georg ZOTTI
@ based on DIST, with direction code added from Sternenbote 7/2002
@ article on quibla direction.


\<< CLLCD
    0 1. FOR i i "TO" "DISTANCE FROM" IFTE       @ i is first 0, then 1!
              SITE.DAT
              1. CHOOSE.T
              IF NOT
              THEN IF i THEN DROP2 END
                   0 DOERR
              END
              2. GET OBJ\-> 3. DROPN
    NEXT
    4. DUPN GEODIST "Dist" \->TAG 5. ROLLD

SWAP NEG 4. ROLL NEG

\-> b1 b2 l2 l1
\<<
    l2 l1 -  b2 COS OVER SIN OVER * @ Dl cosb2 sina.numerator
    3. PICK COS ROT b1 COS * *      @ Dl sina.numerator cosx.left
    b1 SIN b2 SIN * +
    ACOS SIN / ASIN                 @ Dl a

    b2 b1 -

@ Dl a Db

    CASE 3. PICK 0. > THEN CASE DUP 0. > THEN 360. ROT - END @ Dl Db A
                                DUP 0. < THEN 180. ROT + END @ Dl Db A
                                DROP 270. @ Dl a A
                           END
                      END
         3. PICK 0. < THEN CASE DUP 0. > THEN SWAP NEG END @ Dl Db A
                                DUP 0. < THEN SWAP 180. + END @ Dl Db A
                                DROP 90. @ Dl a A
                           END
                      END
         0. > 0. 180. IFTE @ Dl a A
    END
    3. ROLLD DROP2
@ A
    3. RND "Az[NESW]" \->TAG
\>>   
\>>








