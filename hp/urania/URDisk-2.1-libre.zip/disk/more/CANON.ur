%%HP: T(3)A(D)F(.);
@ CANON.UR by Georg Zotti, 07/1999; for Urania V2.1, 01/2000

@ CANON is a helper program mainly for users of the book
@ "Canon of Solar Eclipses -2003 to +2526"
@ (c) 1983 Vienna, by Hermann Mucke and Jean Meeus.

@ Select Besselian elements for a given eclipse and find 
@ local circumstances for Long/Lat/Alt/Zone.
@ Corrections for gravitational vs. figure center is
@ performed, Moon limb profile is not corrected for.

@ The first version of the program was made for the Total Solar Eclipse 1999-8-11. 
@ Here the results were correct to the second for my place!

@ This is by far not a well-done program, however, it works. 
@ Whenever I find time, I might rewrite it, or anyone else.
@ Quite a few parts can be simplified!

@ User programs are: 
@ Size:  (date time) -> size angle_of_moon 
@        calculates size of the eclipse of date/time at location Long/Lat/Alt
@ LOCAL: Select data set and find local circumstances for place Long/Lat/Alt
@ DATA:  enter/delete data sets of Bessel elements

@ V0.1 11.07.1999 Bytes: 8193.5 
@       6.01.2000 Adapted to Urania V2.1
@      17.01.2000 Added Bessel Elements for 2001-06-21 from NASA/Espenak
@      30.06.2000 Bugfix: added DEG mode switch
@ V0.5 19.07.2000 Added Size command, fixed annular eclipses
@ V0.6 17.05.2005 LOCAL-->Local (name conflict with new built-in)

@ SET THE HP49 TO APPROXIMATE MODE DURING UPLOAD

DIR

Size
\<< 
IF DEPTH NOT THEN DATE TIME END
RCLF -42 SF DEG 3 ROLLD
@ flags date time

DUP2 ZT\|>JD JD\|>UT DROP @ "today"_UT
@ search downward, leave index if found, else 0
@ date foundT/F loop_count
        0       BESSEL.DAT SIZE 
WHILE DUP 
REPEAT @ date foundT/F loop_count
       BESSEL.DAT OVER GET HEAD @ date foundT/F loop_count date_entry
       IF 4 PICK == 
       THEN SWAP  @ date loop_count 
       ELSE 1 -
       END
END
@ if found: date loop_count 0
@ if not found: date 0 0 
IF OVER 
THEN DROP BESSEL.DAT SWAP GET 
ELSE DROP2 4 ROLL STOF "No Ecl. data!" KILL @ exit with: flags date time date
END

@ flags date time El-date {bessel-el-for-date}

OBJ\-> DROP 0 0 0 0 0 0 0 0    0 0 0 0 0 0 0 0 0 0
\-> @ \<-DATE \<-TIME | current date/time in question
    \<-date \<-ETmax \<-T0 \<-\Gg \<-X0 \<-X1 \<-Y0 \<-M0 \<-D0 
    \<-Y1   \<-M1    \<-D1 \<-L10 \<-L20 \<-tanF1 \<-L11 \<-L21 \<-tanF2
    \<-t \<-\Gt \<-X \<-Y \<-M \<-D \<-L1 \<-L2 
    \<-H \<-\Gn \<-u \<-v \<-ui \<-vi \<-L1i \<-L2i \<-n \<-psi
 \<< 
DROP @ drop superfluent ecl-date
corr\Gb @ correct for mass center vs. figure center

ZT\|>JD DUP JD\->\GDT + \<-date \<-T0 UT\|>JD - 24 * '\<-t' STO @ contains hours from T0

P22a P22b

\<-L1i  \<-u SQ \<-v SQ + \v/ - 
\<-L1i \<-L2i + /           3 RND "Size"  \->TAG @ G

\<-u \<-v ATN2 360 MOD      3 RND "Angle" \->TAG @ P
\>> 
ROT STOF
\>> @ end of size


Local 
\<< "Select eclipse" BESSEL.DAT 1 CHOOSE.T
IF NOT THEN 0 DOERR END
RCLF SWAP DEG -42 SF
OBJ\-> DROP 0 0 0 0 0 0 0 0    0 0 0 0 0 0 0 0 0 0
\-> \<-date \<-ETmax \<-T0 \<-\Gg \<-X0 \<-X1 \<-Y0 \<-M0 \<-D0 
    \<-Y1   \<-M1    \<-D1 \<-L10 \<-L20 \<-tanF1 \<-L11 \<-L21 \<-tanF2
    \<-t \<-\Gt \<-X \<-Y \<-M \<-D \<-L1 \<-L2 
    \<-H \<-\Gn \<-u \<-v \<-ui \<-vi \<-L1i \<-L2i \<-n \<-psi
 \<< 

corr\Gb @ correct for mass center vs. figure center

@ step one: find out if eclipse is visible; may stop program! 

findM @ Gm Am Pm hm Zm tm | LAMs have values for tm

\<-L1i P23psi COS \<-L1i * \<-n /
@ Gm Am Pm hm Zm tm semidurationPartial | LAMs have values for tm

1 OVER NEG find14 
@ Gm Am Pm hm Zm tm approxSemidurationPartial P1 h1 Z1 t1
6 PICK '\<-t' STO
0 6 ROLL find14 
@ Gm Am Pm hm Zm tm P1 h1 Z1 t1 P4 h4 Z4 t4

@IF 14 PICK 1 \>= |||| G>1 -> centrality: calculate 2nd/3rd contact!
@THEN |"central!"
@ NO LONGER  assume total eclipse (THIS IS BAD CODE!!)
9 PICK '\<-t' STO 0 -.03 find23 
@ Gm Am Pm hm Zm tm P1 h1 Z1 t1 P4 h4 Z4 t4 P2 h2 Z2 t2
1 .06 find23
@ Gm Am Pm hm Zm tm P1 h1 Z1 t1 P4 h4 Z4 t4 P2 h2 Z2 t2 P3 h3 Z3 t3
IF DUP -10000 \=/
THEN 1 
ELSE @ "partial!"
8 DROPN 0 
END
results.OUT
\>>
STOF
\>>



DATA
 \<< "CHANGE ECLIPSE DATA"

 { { "add from CANON"
    \<< "ADD ECLIPSE" DUP

        { { "DATE" "DATE in HP format" 0 }
          { }
          { "ET"   "Maximum ET"        0 }
	  { }

          { "TO"   "TO ET"             0 }
          { "\Gg"  "GAMMA"             0 }
          { "X0"   ""                  0 }
          { "X1"   ""                  0 }
	}
        { 2 0 }
        { }
        DUP
        INFORM
        IF NOT THEN DROP 0 DOERR END
        SWAP @ recover title

	{ { "Y0"   ""                  0 }
          { "M0"   ""                  0 }
          { "D0"   ""                  0 }

          { "Y1"   ""                  0 }
          { "M1"   ""                  0 }
          { "D1"   ""                  0 }


          { "L10"  ""                  0 }
          { "L20"  ""                  0 }
          { "tF1"  "TAN F1"            0 }

          { "L11"  ""                  0 }
          { "L21"  ""                  0 }
          { "tF2"  "TAN F2"            0 }
        }
	{ 3 0 }
	{ }
	DUP
	INFORM
	IF NOT THEN DROP 0 DOERR END
	+  1 \->LIST
        BESSEL.DAT SWAP +
        'BESSEL.DAT' STO
    \>> }

    { "delete"
      \<< "DELETE DATASET"
           BESSEL.DAT 1 CHOOSE.T
           IF NOT THEN 0 DOERR END
           BESSEL.DAT DUP ROT POS       @ {1..n} #
           OVER 1 3 PICK 1 - SUB        @ {1..n} # {1..#-1}
           ROT ROT 1 + OVER SIZE SUB +  @ {1..#-1,#+1..n}
           'BESSEL.DAT' STO
      \>> } }
 1 CHOOSE
 IF THEN EVAL END

\>>


corr\Gb @ correction for Moon's mass center, Par.26:
\<< 0.000175  \<-Y1 SQ \<-X1 SQ + \v/ / @ 0.000175/N
DUP \<-Y1 *     '\<-X0' STO+
    \<-X1 * NEG '\<-Y0' STO+
\>>


find23 @ 0/1_3rdcontact?  semidurationTotal -> P23 h23 Z23 t23 | and set LAMs for t23
       @                                or  -> 0 0 0 -10000 if no 2nd/3rd contact  
\<<
DO '\<-t' STO+ 
   P22a P22b 
   \<-L2i P23psi IF DUP TYPE @ something other than real number: |sin(psi)|>1
		 THEN DROP -10000 '\<-psi' STO 
                      0 @ fake tau
		 ELSE
                      IF OVER THEN NEG 180 + END DUP '\<-psi' STO 
	                            COS \<-L2i P23\Gt
		 END		    
UNTIL DUP ABS .000012 < 
END
SWAP DROP @ discard |invert?|
IF \<-psi -10000 == @ no contact?
THEN 0 0 -10000
ELSE
     '\<-t' STO+ @ now t and LAMs =t(3rdContact) etc.
     P23P
     P23hq
     3 PICK SWAP - 
     \<-t 
END
\>>

find14 @ 0/1...1stcontact? semidurationPartial -> P1|4 h1|4 Z1|4 t1|4 | and set LAMs for t1|t4
\<<
DO '\<-t' STO+ 
   P22a P22b 
   \<-L1i P23psi IF OVER THEN NEG 180 + END DUP '\<-psi' STO 
			                        COS \<-L1i P23\Gt
UNTIL DUP ABS .000012 < 
END
'\<-t' STO+ @ now t and LAMs =t(1stContact) etc.
DROP
P23P
P23hq
3 PICK SWAP - 
\<-t 
\>>




P23P @ ... -> P 
\<< \<-ui \<-vi / ATAN IF DUP 0 < THEN 180 + END \<-psi + \>>
    

P23psi @ ... Li -> psi_1.,4.quadrant ... | for current LAMs and Li=L1' or L2'
\<< \<-u \<-vi * \<-ui \<-v * - \<-n ROT * / ASIN \>>

P23\Gt @ cosPsi L' -> tau
\<< * \<-n / \<-u \<-ui * \<-v \<-vi * + \<-n SQ / - \>>

P23hq @ ... -> ... h q | for current LAMs
\<< \<-D SIN Lat SIN * \<-D COS Lat COS * \<-H COS * + ASIN
    Lat COS \<-H SIN * OVER COS / ASIN
    IF \<-\Gn 0 < THEN 180 SWAP - END
\>>     

findM @ ... -> Gm Am Pm hm Zm tm | LAMs get values for tm
@ find values for mid-eclipse 
\<<
0
DO '\<-t' STO+
   P22a P22b P24a  
UNTIL DUP ABS .000012 < @ tau_m less than 1/20 second
END
'\<-t' STO+ @ now t and LAMs =t(max) etc.
P24b @ G A Pm 
IF 3 PICK 0 \<= THEN 3 DROPN STOF "Not Visible!" KILL END
P23hq @ Gm Am Pm hm qm
3 PICK SWAP - \<-t @ Gm Am Pm hm Zm tm | LAMs have values for tm
\>>

P22a @ ... -> ... ; initializes X,Y,M,D,L1,L2
\<< \<-t
    \<-X1 OVER * \<-X0 + '\<-X' STO
    \<-Y1 OVER * \<-Y0 + '\<-Y' STO
    \<-M1 OVER * \<-M0 + '\<-M' STO
    \<-D1 OVER * \<-D0 + '\<-D' STO
    \<-L11 OVER * \<-L10 + '\<-L1' STO
    \<-L21      * \<-L20 + '\<-L2' STO
\>>

P22b @ ... -> ...; calculates and sets  H \Gh u v ui vi L1i L2i n
\<<
    \<-M Long + \<-date \<-ETmax UT\|>JD JD\->\GDT 86400 * .0041781 * -
    GEOOBS                @ H rsinphi rcosphi
    3 PICK SIN OVER *     @ H rsinphi rcosphi xi
    4 PICK COS \<-D SIN \<-D COS @ H rsinphi rcosphi Xi cosH sinD cosD
    6 PICK OVER *   6 PICK 5 PICK * 4 PICK * - DUP '\<-\Gn' STO 
    @ H rsinphi rcosphi xi cosH sinD cosD eta
    7 ROLL 4 PICK *    ROT 7 PICK *  5 PICK * +  
    @ H rcosphi xi cosH sinD eta zeta
    .0174533 \<-M1 *
    7 ROLL 6 ROLL * OVER * @ xii
    @ H xi sinD eta zeta 0.017M1  xii
    6 PICK ROT * 5 ROLL *
    @ H xi eta zeta xii etai
    \<-X 6 ROLL - 
    \<-Y 6 ROLL - 
    \<-X1 5 ROLL -
    \<-Y1 5 ROLL - 
    @ H zeta u v ui vi
    \<-L1 6 PICK \<-tanF1 * -
    \<-L2 7 ROLL \<-tanF2 * - @ H u v ui vi L1i L2i
    4 PICK SQ 4 PICK SQ + \v/
    '\<-n' STO '\<-L2i' STO '\<-L1i' STO '\<-vi' STO  
    '\<-ui' STO '\<-v' STO '\<-u' STO '\<-H' STO  

\>>

P24a @  -> tau_m
@ uses: <-u <-ui <-v <-vi <-n  
\<< \<-u \<-ui * \<-v \<-vi * + NEG \<-n SQ / \>>

P24b @ -> G A Pm
@ uses: <-u <-v <-ui <-vi <-n <-L1i <-L2i
\<< \<-L1i \<-L2i + 
    \<-L1i 
    \<-v \<-ui * \<-u \<-vi * - \<-n / ABS -
    OVER /
    \<-L1i \<-L2i - ROT /
    @ Gm Am
    \<-vi NEG \<-ui / ATAN 
    IF \<-v 0 < THEN 180 + END
\>>    

results.OUT @ prettyprinting!
@ Gm Am Pm hm Zm tm P1 h1 Z1 t1 P4 h4 Z4 t4 P2 h2 Z2 t2 P3 h3 Z3 t3 1
@ or
@ Gm Am Pm hm Zm tm P1 h1 Z1 t1 P4 h4 Z4 t4 0
@ -> (GROB with text)
\<<

\<-date \<-ETmax UT\|>JD JD\->\GDT DUP 86400 * 
                                  SWAP -24 * Zone EVAL + '\<-T0' STO+ 
@ patched T0 to match Zone&DeltaT
PICT PURGE { # 0d # 0d } PVIEW

PICT { # 0d # 52d } "Date: " \<-date SPLITDATE DAT$ + 
     "  \GDT: " + 4 ROLL 1 REAL$ + 
     g1ReplPict

     { # 0d # 0d } "Eclipse is " 
     IF 4 PICK THEN "central-" IF 27 PICK 1 < 
                               THEN "annular" 
			       ELSE "total" 
			       END 
			       +        
	       ELSE "partial" 
	       END
     + g1ReplPict    
     { # 0d # 15d } "CONTACT  TIME     PA   ZA    ALT" 1 \->GROB REPL
IF THEN @ print 2nd/3rd contact:

IF 21 PICK 1 < @ in case of annular eclipse: swap 2nd/3rd data!
THEN 1 4 START 8 ROLL NEXT
END

 PICT { #  0d # 27d } "2nd" g1ReplPict
 { # 30d # 27d } 7 ROLL \<-T0 + 24 MOD \->HMS TIM$ g1ReplPict
@ 1 FIX
 { # 66d # 27d } 9 ROLL 360 MOD 1 REAL$ 5 PAD$ g1ReplPict
 { # 90d # 27d } 7 ROLL 360 MOD 1 REAL$ 5 PAD$ g1ReplPict
 { #112d # 27d } 7 ROLL         1 REAL$ 5 PAD$ g1ReplPict

 { #  0d # 39d } "3rd" g1ReplPict
 { # 30d # 39d } ROT \<-T0 + 24 MOD \->HMS TIM$ g1ReplPict
 { # 66d # 39d } 5 ROLL 360 MOD 1 REAL$ 5 PAD$ g1ReplPict
 { # 90d # 39d } ROT 360 MOD 1 REAL$    5 PAD$ g1ReplPict
 { #112d # 39d } ROT         1 REAL$    5 PAD$ 1 \->GROB REPL
END @ Now, all that's left is:
@ Gm Am Pm hm Zm tm P1 h1 Z1 t1 P4 h4 Z4 t4 
 PICT { #  0d # 21d } "1st" g1ReplPict
 { # 30d # 21d } 7 ROLL \<-T0 + 24 MOD \->HMS TIM$  g1ReplPict
@ 1 FIX
 { # 66d # 21d } 9 ROLL 360 MOD 1 REAL$ 5 PAD$ g1ReplPict
 { # 90d # 21d } 7 ROLL 360 MOD 1 REAL$ 5 PAD$ g1ReplPict
 { #112d # 21d } 7 ROLL         1 REAL$ 5 PAD$ g1ReplPict
 { #  0d # 45d } "4th" g1ReplPict
 { # 30d # 45d } ROT \<-T0 + 24 MOD \->HMS TIM$ g1ReplPict
 1 FIX
 { # 66d # 45d } 5 ROLL 360 MOD 1 REAL$ 5 PAD$ g1ReplPict
 { # 90d # 45d } ROT 360 MOD 1 REAL$ 5 PAD$ g1ReplPict
 { #112d # 45d } ROT         1 REAL$ 5 PAD$ g1ReplPict
@ Gm Am Pm hm Zm tm PICT
 { #  0d # 33d } "Max" g1ReplPict
 { # 30d # 33d } ROT \<-T0 + 24 MOD \->HMS TIM$ g1ReplPict
 1 FIX
 { # 66d # 33d } 5 ROLL 360 MOD 1 REAL$ 5 PAD$ g1ReplPict
 { # 90d # 33d } ROT 360 MOD    1 REAL$ 5 PAD$ g1ReplPict
 { #112d # 33d } ROT            1 REAL$ 5 PAD$ g1ReplPict
@ Gm Am PICT
 { # 0d #  7d } "Max size: " 5 ROLL 100 * 2 REAL$ +
     "% Moon:Sun=" + 4 ROLL 4 REAL$ + g1ReplPict

 { # 0d # 58d } "Obs:L:" Long DUP ABS 4 REAL$ SWAP 
  IF 0 < THEN "\^oW B:" ELSE "\^oE B:" END + +
  Lat DUP ABS 4 REAL$ SWAP IF 0 < THEN "\^oS " ELSE "\^oN " END + + 
  Zone$ + 1 \->GROB REPL

{ } PVIEW
\>>

g1ReplPict @ just an abbreviation...
\<< 1 \->GROB REPL PICT \>>


BESSEL.DAT @ the Besselian Elements for certain eclipses: Examples and
@ the coming 1999-08-11
@ format: date ETmax T0 GAMMA X0 X1 Y0 M0 D0 
@         Y1 M1 D1 L10 L20 tanF1 L11 L21 tanF2
{
 { 28.031596 19.4221 20.00 -0.5588 0.40163 0.44465 -0.41623 118.754 3.309
   0.24647 15.0044 0.0156 0.56838 0.02214 0.004675 0.00004 0.00004 0.004652}
 { 22.091596 4.0606 4.00 0.5089 0.19762 0.49502 0.47245 241.860 0.294
   -0.27612 15.0047 -0.0156 0.54096 -0.00514 0.004667 -0.00009 -0.00009 0.004644 }
 { 15.021961 8.1947 8.00 .8830 -.40317 .56142 .80848 296.439 -12.716 
   .14303 15.0019 0.0139 .53876 -.00733 .004733 .00006 .00006 .004709 }
 { 20.071963 20.3614 21.00 .6571 .28269 .55048 .63232 133.438 20.679
   -.05439 15.0008 -.0077 0.54361 -.00250 .004601 .00011 .00011 .004578 }
 { 30.051984 16.4541 17.00 .2755 .05609 .52088 .29862 75.616 21.869
   .13301 14.9999 .0057 .55107 .00492 .004612  -.00012 -.00012 .004589 }
 { 11.081999 11.0409 11.00 .5062 .07009 .54430 .50276 343.687 15.327
   -.11849 15.0030 -.0120 .54245 -.00366 .004613 .00012 .00012 .004590 }
 { :Espenak:11.081999 11.040901 11.00 .50623 .0700559 .5443045 
   .5028388 343.690308 15.3273401 -.1184931 15.002983 -.0120348
   .5424893 -.0036496 .0046129 .0001168 .0001163 .0045900 }
 { 21.062001 12.0446 12.00 -.5701 .01037 .56537 -.57183 359.560 23.440
   .05513 14.9992 -.0002 .53695 -.00913 .004600 -.00009 -.00009 .004578 }
 { :Espenak:21.062001 12.044626 12.00 -.57014 .0103551 .5653870 -.5718306 359.564514 23.4397678
   .0551258 14.999194 -.0001831 .5369922 -.0091193 .0046005 -.0000944 -.0000939 .0045776 }
 { 4.122002 7.3215 8.00 -.3020 .18639 .55324 -.35443 302.481 -22.226
   -.13091 14.9973 -.0053 .54415 -.00197 .004744 .00008 .00008 .004720}
 { 3.102005 10.3245 10.00 .3305 -.08920 .45544 .42641 332.749 -4.077 
   -.25081 15.0043 -.0155 .56273 .01653 .004674 -.00008 -.00008 .004651 }
 { 29.032006 10.1222 10.00 .3844 -.28989 .50608 .27911 328.793 3.399 
   .27899 15.0044 .0156 .53698 -.00910 .004683 .00006 .00006 .004659 }
 { 1.082008 10.2211 10.00 .8305 .10173 .52857 .85038 328.426 17.868 
  -.20252 15.0020 -.0101 .53821 -.00787 .004607 .00011 .00011 .004584 }
 
}

END @ DIR

