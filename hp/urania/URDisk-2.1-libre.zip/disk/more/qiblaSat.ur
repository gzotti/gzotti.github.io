%%HP: T(3)A(D)F(.);
@ QiblaSat finds the time when the sun is at azimuth of Mekka, 
@ important for muslims.
@ Using Transversal Sentence: Spektrum d. Wiss. Spezial, Mittelalter, 2002: p.27
@       Neper's rule: Bartsch, Taschenbuch Math. Formeln, p.252
@ (c) 2004 Georg ZOTTI 11.12.2004
@ Currently works for sites north of tropic of Cancer, for all solar declinations.
@ TODO: make sure it works 
@       - for sites between tropics, north of Mecca
@       - for sites between tropics, south of Mecca
@       - for sites south of tropic of Capricorn
@ check with:  DUP qiblaSat.ur DUP 3. ROLLD 10. Display.T
@ 1: (Date) --> 1: :QbSat: HH.MMd

\<<
IF DEPTH NOT THEN DATE END         @ default: current date
0. DUP2 EQTM HMS\-> 15. * 3. ROLLD 
UT\|>JD JD\->T 0. SunPos DROP \Gl\Gb\Ga\Gd SWAP DROP HMS\->
Long Lat QIBLA
\-> eqTm dec q
\<<
q COS NEG 
Lat COS q SIN * ACOS @ alpha
SIN / ACOS @ AwA
DUP SIN dec TAN * Lat TAN / ASIN @ AsA
-  Long 39.823333 - 180. + 360. MOD 180. -  SIGN *
@ Stack: t=Stundenwinkel,Grad

  IF Lat 21.423333  < @ south of Mecca: 'invert' angle
  THEN 180. SWAP -
  END
  Long Zone EVAL 15. * - - @ or +?: longitude correction to Zone time
  eqTm -
  15. / 12. + 24. MOD  \->HMd
  3. RND "QiblaSat" \->TAG
\>>   
\>>







