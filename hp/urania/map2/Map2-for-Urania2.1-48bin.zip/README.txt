MAP2, a better planisphere for Urania V2.1 by Georg Zotti

Written by Dominique Rodriguez

This README by Georg Zotti


This package contains a beta version of Map2. It should work for HP48G
series. Upload both libraries in your HP48GX, store into any port. If
possible, use port 0 for Map2.lib for best performance.



 HELP WANTED! -- GET A FREE FULL VERSION OF URANIA!
====================================================

Dominique first programmed Map2 in 1996-99 for Urania/48, V2.0. In 2000,
I asked if he could port it to V2.1 and also to the HP49G. He has no
HP49G, but he did a version which now works from any port on the HP48.

Unfortunately, he has no more time to support the program. And my
(lack of) knowledge of Assembler and some internal details of the HP49
(and lack of time as well) will not allow me to do the port myself. I
started with the things I could do, and it compiles with the HPTools
3.0.6 for the HP49G, but then it warmstarts the calculator. If you are
willing to help, please contact me. You will be given a free
"Developer's License" (unlimited AARes and Urania libraries) during
development and a free full version of both Urania/49 AND Urania/48 as
soon as Map2 is running from any port.  Of course, you will be given a
full license and full credit in the manual for an upcoming version 2.2.

As you see, I am _very_ interested to see this program running on the
HP49G!



Vienna, Austria, January 1st, 2002

Georg Zotti

mailto:gzotti@cg.tuwien.ac.at
